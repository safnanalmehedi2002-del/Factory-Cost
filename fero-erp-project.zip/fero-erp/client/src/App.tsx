import { useCallback, useEffect, useState } from 'react';
import { Calculator, ClipboardList, Factory, FileSpreadsheet, Package, Scissors, Siren } from 'lucide-react';
import { api, type Dashboard, type Order, type Recon, type Trim } from './api';
import OrdersTab from './components/OrdersTab';
import ProductionTab from './components/ProductionTab';
import FabricGridTab from './components/FabricGridTab';
import ReconTrimsTab from './components/ReconTrimsTab';
import YieldCalculator from './components/YieldCalculator';
import { ErrorBar, Modal, Num } from './components/ui';

const TABS = [
  { id: 'orders', label: 'Master Orders', icon: ClipboardList },
  { id: 'prod', label: 'Production', icon: Factory },
  { id: 'fabric', label: 'Cutting & Fabric', icon: Scissors },
  { id: 'recon', label: 'Recon & Trims', icon: Package },
] as const;
type TabId = (typeof TABS)[number]['id'];

export default function App() {
  const [tab, setTab] = useState<TabId>('orders');
  const [dash, setDash] = useState<Dashboard | null>(null);
  const [orders, setOrders] = useState<Order[]>([]);
  const [recon, setRecon] = useState<Recon | null>(null);
  const [trims, setTrims] = useState<Trim[]>([]);
  const [version, setVersion] = useState(0);
  const [error, setError] = useState('');
  const [calc, setCalc] = useState(false);
  const [exp, setExp] = useState(false);

  const reload = useCallback(async () => {
    try {
      const [d, o, r, t] = await Promise.all([api.dashboard(), api.orders(), api.recon(), api.trims()]);
      setDash(d); setOrders(o); setRecon(r); setTrims(t); setVersion((v) => v + 1);
    } catch (e) { setError((e as Error).message); }
  }, []);
  useEffect(() => { reload(); }, [reload]);

  const alerts = dash?.criticalAlerts;
  const kpis = [
    { label: 'Total order qty', v: dash?.totalOrderQty },
    { label: 'Total cut', v: dash?.totalCut },
    { label: 'Total packed', v: dash?.totalPacked },
    { label: 'Active floor WIP', v: dash?.activeFloorWip },
  ];

  return (
    <div className="min-h-screen bg-slate-950 text-slate-200">
      <header className="border-b border-slate-800 bg-gradient-to-b from-slate-900 to-slate-950">
        <div className="mx-auto max-w-[1500px] px-4 py-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <h1 className="text-xl font-bold tracking-wide text-emerald-400 sm:text-2xl">FERO FASHION HOUSE LTD.</h1>
              <p className="text-xs text-slate-400">
                {orders.length ? `${new Set(orders.map((o) => o.buyerName)).size} buyers · ${orders.length} styles on the books` : 'Production & fabric control'}
              </p>
            </div>
            <div className="flex gap-2">
              <button className="btn-ghost" onClick={() => setCalc(true)}><Calculator size={15} /> Yield calculator</button>
              <button className="btn-ghost" onClick={() => setExp(true)}><FileSpreadsheet size={15} /> Export to Sheets</button>
            </div>
          </div>

          <div className="mt-4 grid grid-cols-2 gap-3 md:grid-cols-5">
            {kpis.map((k) => (
              <div key={k.label} className="card p-3">
                <div className="text-[11px] uppercase tracking-wide text-slate-400">{k.label}</div>
                <div className="mt-1 text-2xl font-semibold text-slate-100">{k.v == null ? '—' : <Num v={k.v} />}</div>
              </div>
            ))}
            <div className={`card p-3 ${alerts?.total ? 'border-red-500/40' : ''}`} title={alerts ? `${alerts.delayed} delayed · ${alerts.urgent} urgent · ${alerts.fabricShortage} fabric shortage · ${alerts.lowTrims} low trims` : ''}>
              <div className="flex items-center gap-1 text-[11px] uppercase tracking-wide text-slate-400"><Siren size={12} /> Critical alerts</div>
              <div className={`mt-1 text-2xl font-semibold ${alerts?.total ? 'text-red-300' : 'text-emerald-300'}`}>{alerts ? alerts.total : '—'}</div>
              {alerts && <div className="mt-0.5 truncate text-[11px] text-slate-500">{alerts.delayed} late · {alerts.urgent} urgent · {alerts.fabricShortage} fabric · {alerts.lowTrims} trims</div>}
            </div>
          </div>

          <nav className="mt-4 flex gap-1 overflow-x-auto" aria-label="Sections">
            {TABS.map(({ id, label, icon: Icon }) => (
              <button key={id} onClick={() => setTab(id)} className={`inline-flex items-center gap-1.5 whitespace-nowrap rounded-md px-3 py-2 text-sm font-medium ${tab === id ? 'bg-slate-800 text-emerald-300' : 'text-slate-400 hover:bg-slate-900 hover:text-slate-200'}`}>
                <Icon size={15} /> {label}
              </button>
            ))}
          </nav>
        </div>
      </header>

      <main className="mx-auto max-w-[1500px] px-4 py-5">
        {error && <ErrorBar msg={error} onClose={() => setError('')} />}
        {tab === 'orders' && <OrdersTab orders={orders} reload={reload} onError={setError} />}
        {tab === 'prod' && <ProductionTab orders={orders} reload={reload} onError={setError} version={version} />}
        {tab === 'fabric' && <FabricGridTab orders={orders} reload={reload} onError={setError} version={version} />}
        {tab === 'recon' && <ReconTrimsTab orders={orders} recon={recon} trims={trims} reload={reload} onError={setError} />}
      </main>

      {calc && <YieldCalculator onClose={() => setCalc(false)} />}
      {exp && <ExportModal onClose={() => setExp(false)} />}
    </div>
  );
}

function ExportModal({ onClose }: { onClose: () => void }) {
  const [email, setEmail] = useState('');
  const [sheetId, setSheetId] = useState(() => { try { return localStorage.getItem('fero.sheetId') ?? ''; } catch { return ''; } });
  const [busy, setBusy] = useState(false);
  const [res, setRes] = useState<{ url: string; tabs: { name: string; rows: number }[] } | null>(null);
  const [err, setErr] = useState('');

  async function run() {
    setBusy(true); setErr(''); setRes(null);
    try {
      const out = await api.exportSheets({ shareWith: email ? email.split(',').map((s) => s.trim()).filter(Boolean) : undefined, spreadsheetId: sheetId.trim() || undefined });
      setRes(out);
      try { localStorage.setItem('fero.sheetId', out.spreadsheetId); } catch { /* storage unavailable */ }
      setSheetId(out.spreadsheetId);
    } catch (e) { setErr((e as Error).message); } finally { setBusy(false); }
  }

  return (
    <Modal title="Export to Google Sheets" onClose={onClose}>
      <p className="mb-3 text-sm text-slate-400">Creates a spreadsheet with Master Orders, Daily Production, Cutting &amp; Fabric, Fabric Recon and Trims tabs. Re-run with the same spreadsheet ID to refresh it in place.</p>
      <label className="lbl">Share with (comma-separated emails, optional)</label>
      <input className="inp mb-3" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="planner@fero.com" />
      <label className="lbl">Existing spreadsheet ID (optional — refresh in place)</label>
      <input className="inp mb-4 font-mono" value={sheetId} onChange={(e) => setSheetId(e.target.value)} />
      {err && <ErrorBar msg={err} onClose={() => setErr('')} />}
      {res && (
        <div className="mb-3 rounded-md border border-emerald-500/30 bg-emerald-500/10 p-3 text-sm text-emerald-200">
          Exported {res.tabs.map((t) => `${t.name} (${t.rows})`).join(', ')}.{' '}
          <a className="underline" href={res.url} target="_blank" rel="noreferrer">Open spreadsheet</a>
        </div>
      )}
      <div className="flex justify-end gap-2">
        <button className="btn-ghost" onClick={onClose}>Close</button>
        <button className="btn" onClick={run} disabled={busy}>{busy ? 'Exporting…' : 'Export now'}</button>
      </div>
    </Modal>
  );
}
