/**
 * Calculation engine — pure functions, no dependencies.
 * Keep this file byte-identical with client/src/lib/calc.ts (see `npm run sync:calc` in README).
 */
export type Unit = 'CM' | 'INC';
export type OrderStatus =
  | 'NOT_STARTED'
  | 'IN_PRODUCTION'
  | 'URGENT_DUE'
  | 'DELAYED_CRITICAL'
  | 'COMPLETED';

export const CM_PER_INCH = 2.54;
export const LB_PER_KG = 2.2046226218;

export const round = (n: number, dp = 4): number => {
  const f = 10 ** dp;
  return Math.round((n + Number.EPSILON) * f) / f;
};

/** Convert a length between CM and INC. Full float precision; round only for display. */
export function convertLength(v: number, from: Unit, to: Unit): number {
  if (from === to) return v;
  return from === 'INC' ? v * CM_PER_INCH : v / CM_PER_INCH;
}
export const toCm = (v: number, u: Unit) => convertLength(v, u, 'CM');

export const kgToLb = (kg: number) => kg * LB_PER_KG;
export const lbToKg = (lb: number) => lb / LB_PER_KG;

export interface KnitYieldInput {
  unit: Unit;
  bodyLength: number;
  chestHalf: number;
  sleeveLength: number;
  gsm: number;
  wastagePct: number;
}

/**
 * Knit / T-shirt consumption (kg per piece):
 *   ((Body + Sleeve + 10) * (ChestHalf + 5) * 2 * GSM) / 10,000,000 * (1 + wastage/100)
 * All dimensions in CM (+10 / +5 are CM allowances). cm*cm*g/m² / 1e7 = kg.
 */
export function consumptionPerPcKg(i: KnitYieldInput): number {
  const body = toCm(i.bodyLength, i.unit);
  const sleeve = toCm(i.sleeveLength, i.unit);
  const chest = toCm(i.chestHalf, i.unit);
  const base = ((body + sleeve + 10) * (chest + 5) * 2 * i.gsm) / 10_000_000;
  return base * (1 + i.wastagePct / 100);
}
export const consumptionPerDozenKg = (i: KnitYieldInput) => consumptionPerPcKg(i) * 12;

export interface WovenYieldInput {
  unit: Unit;
  markerLength: number; // length of the marker
  fabricWidth: number; // usable width (dia)
  pcsPerMarker: number;
  gsm: number;
  wastagePct: number;
}

/** Woven marker based consumption (kg per piece). */
export function wovenConsumptionPerPcKg(i: WovenYieldInput): number {
  if (i.pcsPerMarker <= 0) return 0;
  const lenM = toCm(i.markerLength, i.unit) / 100;
  const widM = toCm(i.fabricWidth, i.unit) / 100;
  const kgPerMarker = (lenM * widM * i.gsm) / 1000;
  return (kgPerMarker / i.pcsPerMarker) * (1 + i.wastagePct / 100);
}

export interface FlowTotals {
  orderQty: number;
  cut: number;
  sewIn: number;
  sewOut: number;
  packed: number;
}

export function computeWip(t: FlowTotals) {
  return {
    cuttingBalance: t.orderQty - t.cut,
    cutToSewWip: t.cut - t.sewIn,
    sewingFloorWip: t.sewIn - t.sewOut,
    finishingWip: t.sewOut - t.packed,
    totalFloorWip: t.cut - t.packed,
  };
}

/** Fabric Balance (Kg) = Received − Required for cut pieces */
export function fabricBalanceKg(receivedKg: number, cutPcs: number, consPerPcKg: number) {
  const requiredForCut = cutPcs * consPerPcKg;
  return { requiredForCut, balance: receivedKg - requiredForCut };
}

export function reconcile(requiredKg: number, receivedKg: number, avgConsPerPc: number) {
  const shortageKg = Math.max(0, requiredKg - receivedKg);
  const excessKg = Math.max(0, receivedKg - requiredKg);
  const per = avgConsPerPc > 0 ? avgConsPerPc : 0;
  return {
    shortageKg,
    excessKg,
    shortagePcs: per ? Math.ceil(shortageKg / per) : 0,
    excessPcs: per ? Math.floor(excessKg / per) : 0,
  };
}

const DAY = 86_400_000;
const utcDay = (d: Date | string) => {
  const x = new Date(d);
  return Date.UTC(x.getUTCFullYear(), x.getUTCMonth(), x.getUTCDate());
};

/** Whole days from `today` to deadline (negative = overdue). */
export const daysUntil = (deadline: Date | string, today: Date = new Date()) =>
  Math.round((utcDay(deadline) - utcDay(today)) / DAY);

export function deriveStatus(
  o: { orderQty: number; cut: number; packed: number; deadline: Date | string },
  today: Date = new Date(),
): OrderStatus {
  if (o.orderQty > 0 && o.packed >= o.orderQty) return 'COMPLETED';
  const d = daysUntil(o.deadline, today);
  if (d < 0) return 'DELAYED_CRITICAL';
  if (d <= 7) return 'URGENT_DUE';
  return o.cut > 0 ? 'IN_PRODUCTION' : 'NOT_STARTED';
}

export function trimsStatus(t: { received: number; used: number; minBuffer: number; required: number }) {
  const balance = t.received - t.used;
  return {
    balance,
    lowStock: balance < t.minBuffer,
    shortToRequirement: Math.max(0, t.required - t.received),
  };
}
