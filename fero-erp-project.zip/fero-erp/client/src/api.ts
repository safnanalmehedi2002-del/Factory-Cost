import type { Unit, OrderStatus } from './lib/calc';

export interface Wip { cuttingBalance: number; cutToSewWip: number; sewingFloorWip: number; finishingWip: number; totalFloorWip: number }
export interface Order {
  id: number; buyerName: string; styleNo: string; itemDescription: string; colorWash: string;
  totalOrderQty: number; unitConsumptionKg: number; shipmentDeadline: string; daysLeft: number;
  status: OrderStatus;
  cumulative: { cut: number; sewIn: number; sewOut: number; packed: number };
  wip: Wip;
  fabric: { receivedKg: number; requiredTotalKg: number; requiredForCutKg: number; balanceKg: number };
}
export interface Dashboard {
  totalOrderQty: number; totalCut: number; totalPacked: number; activeFloorWip: number;
  criticalAlerts: { total: number; delayed: number; urgent: number; fabricShortage: number; lowTrims: number };
}
export interface ProdRow {
  id: number; orderId: number; buyerName: string; styleNo: string; entryDate: string; lineShift: string; remarks: string | null;
  fabricReceivedKg: number; cuttingDailyPcs: number; sewingInputDailyPcs: number; sewingOutputDailyPcs: number; finishingPackingDailyPcs: number;
  cumulative: { cut: number; sewIn: number; sewOut: number; packed: number; fabric: number };
  wip: Wip;
}
export interface GridRow {
  id: number; orderId: number; slNo: number; fabricType: string; colorRef: string; gsm: number; dia: number; unit: Unit;
  bodyLength: number; chestHalf: number; sleeveLength: number; wastagePct: number; fabricReceivedKg: number; cuttingQtyPcs: number;
  consumptionPerPcKg: number; consumptionPerDozenKg: number; requiredForCutKg: number; balanceKg: number;
  challanNo: string | null; snapshotImageUrl: string | null; remarks: string | null;
}
export interface Recon {
  buyers: { buyer: string; styles: string[]; requiredKg: number; receivedKg: number; avgConsumptionKg: number; shortageKg: number; excessKg: number; shortagePcs: number; excessPcs: number }[];
  styles: { orderId: number; buyer: string; styleNo: string; requiredKg: number; receivedKg: number; shortageKg: number; excessKg: number }[];
}
export interface Trim {
  id: number; orderId: number; buyerName: string; styleNo: string; itemDescription: string; category: string; unit: string;
  totalRequired: number; totalReceived: number; totalUsed: number; minBufferThreshold: number; balance: number; lowStock: boolean; shortToRequirement: number;
}

async function req<T>(path: string, init?: RequestInit): Promise<T> {
  const r = await fetch(`/api${path}`, { headers: { 'Content-Type': 'application/json' }, ...init });
  if (!r.ok) {
    const e = await r.json().catch(() => ({}));
    throw new Error(e.error ?? `Request failed (${r.status})`);
  }
  return r.status === 204 ? (undefined as T) : r.json();
}
const body = (method: string, data: unknown): RequestInit => ({ method, body: JSON.stringify(data) });

export const api = {
  dashboard: () => req<Dashboard>('/dashboard'),
  orders: () => req<Order[]>('/orders'),
  createOrder: (d: unknown) => req('/orders', body('POST', d)),
  deleteOrder: (id: number) => req(`/orders/${id}`, { method: 'DELETE' }),
  production: (orderId?: number) => req<ProdRow[]>(`/production${orderId ? `?orderId=${orderId}` : ''}`),
  addProduction: (d: unknown) => req('/production', body('POST', d)),
  deleteProduction: (id: number) => req(`/production/${id}`, { method: 'DELETE' }),
  grid: (orderId: number) => req<GridRow[]>(`/fabric?orderId=${orderId}`),
  addGrid: (d: unknown) => req('/fabric', body('POST', d)),
  patchGrid: (id: number, d: unknown) => req<GridRow>(`/fabric/${id}`, body('PATCH', d)),
  deleteGrid: (id: number) => req(`/fabric/${id}`, { method: 'DELETE' }),
  convertGrid: (orderId: number, unit: Unit) => req<GridRow[]>('/fabric/convert', body('POST', { orderId, unit })),
  uploadSnapshot: async (id: number, file: File) => {
    const fd = new FormData();
    fd.append('image', file);
    const r = await fetch(`/api/fabric/${id}/snapshot`, { method: 'POST', body: fd });
    if (!r.ok) throw new Error((await r.json().catch(() => ({}))).error ?? 'Upload failed');
    return r.json() as Promise<GridRow>;
  },
  recon: () => req<Recon>('/fabric/reconciliation'),
  trims: () => req<Trim[]>('/trims'),
  addTrim: (d: unknown) => req('/trims', body('POST', d)),
  patchTrim: (id: number, d: unknown) => req(`/trims/${id}`, body('PATCH', d)),
  deleteTrim: (id: number) => req(`/trims/${id}`, { method: 'DELETE' }),
  exportSheets: (d: { title?: string; shareWith?: string[]; spreadsheetId?: string }) =>
    req<{ url: string; spreadsheetId: string; tabs: { name: string; rows: number }[] }>('/export/sheets', body('POST', d)),
};
