import { useState } from 'react';
import { AlertTriangle, CheckCircle2, Plus, Trash2 } from 'lucide-react';
import { api, type Order, type Recon, type Trim } from '../api';
import { Empty, Field, Modal, Num } from './ui';

interface Props { orders: Order[]; recon: Recon | null; trims: Trim[]; reload: () => void; onError: (m: string) => void }

const CATS = ['SEWING_TRIMS', 'PACKING_TRIMS', 'LABELS_TAGS'];
const UNITS = ['PCS', 'GROSS', 'YARDS', 'CONES', 'SETS'];
const blank = { orderId: '', itemDescription: '', category: 'SEWING_TRIMS', unit: 'PCS', totalRequired: '', totalReceived: '', totalUsed: '', minBufferThreshold: '' };

export default function ReconTrimsTab({ orders, recon, trims, reload, onError }: Props) {
  const [open, setOpen] = useState(false);
  const [f, setF] = useState(blank);
  const set = (k: keyof typeof blank) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => setF({ ...f, [k]: e.target.value });
  const low = trims.filter((t) => t.lowStock);

  async function save(e: React.FormEvent) {
    e.preventDefault();
    const n = (v: string) => Number(v || 0);
    try {
      await api.addTrim({ ...f, orderId: Number(f.orderId), totalRequired: n(f.totalRequired), totalReceived: n(f.totalReceived), totalUsed: n(f.totalUsed), minBufferThreshold: n(f.minBufferThreshold) });
      setOpen(false); setF(blank); reload();
    } catch (err) { onError((err as Error).message); }
  }

  /** Inline edit of received / used for quick stock updates. */
  async function bump(t: Trim, key: 'totalReceived' | 'totalUsed', v: string) {
    const val = Number(v);
    if (!Number.isFinite(val) || val < 0 || val === t[key]) return;
    try { await api.patchTrim(t.id, { [key]: val }); reload(); } catch (err) { onError((err as Error).message); }
  }

  async function remove(id: number) {
    if (!confirm('Delete this trim item?')) return;
    try { await api.deleteTrim(id); reload(); } catch (err) { onError((err as Error).message); }
  }

  return (
    <div className="space-y-6">
      <section>
        <h2 className="mb-3 text-base font-semibold text-slate-100">Fabric Reconciliation (buyer-wise)</h2>
        {recon && recon.buyers.some((b) => b.shortageKg > 0) && (
          <div className="mb-3 flex items-start gap-2 rounded-md border border-red-500/30 bg-red-500/10 px-3 py-2 text-sm text-red-300">
            <AlertTriangle size={16} className="mt-0.5 shrink-0" />
            <span>Fabric shortage: {recon.buyers.filter((b) => b.shortageKg > 0).map((b) => `${b.buyer} (${b.shortageKg.toLocaleString()} kg ≈ ${b.shortagePcs.toLocaleString()} pcs)`).join(' · ')}</span>
          </div>
        )}
        <div className="card overflow-x-auto">
          <table className="w-full">
            <thead className="border-b border-slate-800"><tr>{['Buyer', 'Styles', 'Required kg', 'Received kg', 'Shortage kg', 'Excess kg', 'Avg kg/pc', 'Garment impact'].map((h) => <th key={h} className="th">{h}</th>)}</tr></thead>
            <tbody>
              {recon?.buyers.map((b) => (
                <tr key={b.buyer} className="border-b border-slate-800/60 last:border-0">
                  <td className="td font-medium">{b.buyer}</td>
                  <td className="td text-slate-400">{b.styles.join(', ')}</td>
                  <td className="td"><Num v={b.requiredKg} dp={1} /></td>
                  <td className="td"><Num v={b.receivedKg} dp={1} /></td>
                  <td className={`td ${b.shortageKg > 0 ? 'font-semibold text-red-300' : 'text-slate-500'}`}><Num v={b.shortageKg} dp={1} /></td>
                  <td className={`td ${b.excessKg > 0 ? 'font-semibold text-emerald-300' : 'text-slate-500'}`}><Num v={b.excessKg} dp={1} /></td>
                  <td className="td"><Num v={b.avgConsumptionKg} dp={4} /></td>
                  <td className="td">
                    {b.shortageKg > 0 ? <span className="text-red-300">short ≈ <Num v={b.shortagePcs} /> pcs</span>
                      : b.excessKg > 0 ? <span className="text-emerald-300">excess ≈ <Num v={b.excessPcs} /> pcs</span>
                      : <span className="inline-flex items-center gap-1 text-slate-400"><CheckCircle2 size={14} /> balanced</span>}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {!recon?.buyers.length && <Empty>No orders to reconcile.</Empty>}
        </div>
        <p className="mt-2 text-xs text-slate-500">Required = order qty × budget consumption. Received uses challan-backed fabric grid rows (falls back to daily log if a style has no grid rows).</p>
      </section>

      <section>
        <div className="mb-3 flex items-center justify-between">
          <h2 className="text-base font-semibold text-slate-100">Accessories &amp; Trims Stock</h2>
          <button className="btn" onClick={() => { setF({ ...blank, orderId: String(orders[0]?.id ?? '') }); setOpen(true); }} disabled={!orders.length}><Plus size={15} /> Add trim</button>
        </div>
        {low.length > 0 && (
          <div className="mb-3 flex items-start gap-2 rounded-md border border-amber-500/30 bg-amber-500/10 px-3 py-2 text-sm text-amber-300">
            <AlertTriangle size={16} className="mt-0.5 shrink-0" />
            <span><b>Re-order:</b> {low.map((t) => `${t.itemDescription} (${t.styleNo}) — ${t.balance.toLocaleString()} ${t.unit.toLowerCase()} left, min ${t.minBufferThreshold.toLocaleString()}`).join(' · ')}</span>
          </div>
        )}
        <div className="card overflow-x-auto">
          <table className="w-full">
            <thead className="border-b border-slate-800"><tr>{['Style', 'Item', 'Category', 'Unit', 'Required', 'Received', 'Used', 'Balance', 'Min buffer', 'Status', ''].map((h) => <th key={h} className="th">{h}</th>)}</tr></thead>
            <tbody>
              {trims.map((t) => (
                <tr key={t.id} className="border-b border-slate-800/60 last:border-0 hover:bg-slate-800/30">
                  <td className="td">{t.styleNo}<div className="text-xs text-slate-500">{t.buyerName}</div></td>
                  <td className="td">{t.itemDescription}</td>
                  <td className="td text-slate-400">{t.category.replace('_', ' ').toLowerCase()}</td>
                  <td className="td">{t.unit.toLowerCase()}</td>
                  <td className="td"><Num v={t.totalRequired} /></td>
                  <td className="td"><input key={t.totalReceived} defaultValue={t.totalReceived} type="number" min={0} onBlur={(e) => bump(t, 'totalReceived', e.target.value)} className="inp !w-24 !py-1 text-right font-mono" /></td>
                  <td className="td"><input key={t.totalUsed} defaultValue={t.totalUsed} type="number" min={0} onBlur={(e) => bump(t, 'totalUsed', e.target.value)} className="inp !w-24 !py-1 text-right font-mono" /></td>
                  <td className={`td font-semibold ${t.lowStock ? 'text-amber-300' : ''}`}><Num v={t.balance} /></td>
                  <td className="td"><Num v={t.minBufferThreshold} /></td>
                  <td className="td">
                    {t.lowStock ? <span className="rounded-full border border-amber-500/30 bg-amber-500/15 px-2 py-0.5 text-xs text-amber-300">Re-order</span>
                      : t.shortToRequirement > 0 ? <span className="text-xs text-slate-400">{t.shortToRequirement.toLocaleString()} to receive</span>
                      : <span className="text-xs text-emerald-400">OK</span>}
                  </td>
                  <td className="td"><button onClick={() => remove(t.id)} className="text-slate-500 hover:text-red-400" aria-label="Delete trim"><Trash2 size={15} /></button></td>
                </tr>
              ))}
            </tbody>
          </table>
          {!trims.length && <Empty>No trims tracked yet.</Empty>}
        </div>
      </section>

      {open && (
        <Modal title="Add trim / accessory" onClose={() => setOpen(false)}>
          <form onSubmit={save} className="grid grid-cols-2 gap-3">
            <Field label="Style" className="col-span-2">
              <select required className="inp" value={f.orderId} onChange={set('orderId')}>
                {orders.map((o) => <option key={o.id} value={o.id}>{o.buyerName} — {o.styleNo}</option>)}
              </select>
            </Field>
            <Field label="Item description" className="col-span-2"><input required className="inp" value={f.itemDescription} onChange={set('itemDescription')} /></Field>
            <Field label="Category"><select className="inp" value={f.category} onChange={set('category')}>{CATS.map((c) => <option key={c} value={c}>{c.replace('_', ' ')}</option>)}</select></Field>
            <Field label="Unit"><select className="inp" value={f.unit} onChange={set('unit')}>{UNITS.map((u) => <option key={u}>{u}</option>)}</select></Field>
            <Field label="Total required"><input type="number" min={0} className="inp" value={f.totalRequired} onChange={set('totalRequired')} /></Field>
            <Field label="Total received"><input type="number" min={0} className="inp" value={f.totalReceived} onChange={set('totalReceived')} /></Field>
            <Field label="Total used"><input type="number" min={0} className="inp" value={f.totalUsed} onChange={set('totalUsed')} /></Field>
            <Field label="Min buffer threshold"><input type="number" min={0} className="inp" value={f.minBufferThreshold} onChange={set('minBufferThreshold')} /></Field>
            <div className="col-span-2 flex justify-end gap-2 pt-2"><button type="button" className="btn-ghost" onClick={() => setOpen(false)}>Cancel</button><button className="btn">Save</button></div>
          </form>
        </Modal>
      )}
    </div>
  );
}
