import { useState } from 'react';
import { Plus, Trash2 } from 'lucide-react';
import { api, type Order } from '../api';
import { Empty, Field, Modal, Num, StatusBadge } from './ui';

interface Props { orders: Order[]; reload: () => void; onError: (m: string) => void }

export default function OrdersTab({ orders, reload, onError }: Props) {
  const [open, setOpen] = useState(false);
  const [f, setF] = useState({ buyerName: '', styleNo: '', itemDescription: '', colorWash: '', totalOrderQty: '', unitConsumptionKg: '', shipmentDeadline: '' });
  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement>) => setF({ ...f, [k]: e.target.value });

  async function save(e: React.FormEvent) {
    e.preventDefault();
    try {
      await api.createOrder({ ...f, totalOrderQty: Number(f.totalOrderQty), unitConsumptionKg: Number(f.unitConsumptionKg) });
      setOpen(false);
      setF({ buyerName: '', styleNo: '', itemDescription: '', colorWash: '', totalOrderQty: '', unitConsumptionKg: '', shipmentDeadline: '' });
      reload();
    } catch (err) { onError((err as Error).message); }
  }

  async function remove(o: Order) {
    if (!confirm(`Delete ${o.styleNo} and ALL its production, fabric and trims records?`)) return;
    try { await api.deleteOrder(o.id); reload(); } catch (err) { onError((err as Error).message); }
  }

  // group by buyer
  const buyers = [...new Set(orders.map((o) => o.buyerName))];

  return (
    <div>
      <div className="mb-3 flex items-center justify-between">
        <h2 className="text-base font-semibold text-slate-100">Master Order Summary</h2>
        <button className="btn" onClick={() => setOpen(true)}><Plus size={15} /> New order</button>
      </div>
      <div className="card overflow-x-auto">
        <table className="w-full">
          <thead className="border-b border-slate-800">
            <tr>{['Style', 'Item / Wash', 'Order Qty', 'Cut', 'Packed', 'Cut Bal.', 'Floor WIP', 'Shipment', 'Status', ''].map((h) => <th key={h} className="th">{h}</th>)}</tr>
          </thead>
          <tbody>
            {buyers.map((b) => (
              <BuyerGroup key={b} buyer={b} rows={orders.filter((o) => o.buyerName === b)} remove={remove} />
            ))}
          </tbody>
        </table>
        {!orders.length && <Empty>No orders yet. Add your first style.</Empty>}
      </div>

      {open && (
        <Modal title="New master order" onClose={() => setOpen(false)}>
          <form onSubmit={save} className="grid grid-cols-2 gap-3">
            <Field label="Buyer"><input required className="inp" value={f.buyerName} onChange={set('buyerName')} /></Field>
            <Field label="Style no."><input required className="inp" value={f.styleNo} onChange={set('styleNo')} /></Field>
            <Field label="Item description" className="col-span-2"><input required className="inp" value={f.itemDescription} onChange={set('itemDescription')} /></Field>
            <Field label="Color / wash"><input required className="inp" value={f.colorWash} onChange={set('colorWash')} /></Field>
            <Field label="Order qty (pcs)"><input required type="number" min={1} className="inp" value={f.totalOrderQty} onChange={set('totalOrderQty')} /></Field>
            <Field label="Consumption (kg/pc)"><input required type="number" step="0.0001" min={0} className="inp" value={f.unitConsumptionKg} onChange={set('unitConsumptionKg')} /></Field>
            <Field label="Shipment deadline"><input required type="date" className="inp" value={f.shipmentDeadline} onChange={set('shipmentDeadline')} /></Field>
            <div className="col-span-2 flex justify-end gap-2 pt-2">
              <button type="button" className="btn-ghost" onClick={() => setOpen(false)}>Cancel</button>
              <button className="btn">Save order</button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
}

function BuyerGroup({ buyer, rows, remove }: { buyer: string; rows: Order[]; remove: (o: Order) => void }) {
  return (
    <>
      <tr className="bg-slate-800/40">
        <td colSpan={10} className="px-3 py-1.5 text-xs font-semibold uppercase tracking-wider text-emerald-400">{buyer}</td>
      </tr>
      {rows.map((o) => (
        <tr key={o.id} className="border-b border-slate-800/60 last:border-0 hover:bg-slate-800/30">
          <td className="td font-medium">{o.styleNo}</td>
          <td className="td">{o.itemDescription}<div className="text-xs text-slate-500">{o.colorWash}</div></td>
          <td className="td"><Num v={o.totalOrderQty} /></td>
          <td className="td"><Num v={o.cumulative.cut} /></td>
          <td className="td"><Num v={o.cumulative.packed} /></td>
          <td className="td"><Num v={o.wip.cuttingBalance} signed /></td>
          <td className="td"><Num v={o.wip.totalFloorWip} /></td>
          <td className="td">
            {o.shipmentDeadline.slice(0, 10)}
            <div className={`text-xs ${o.daysLeft < 0 && o.status !== 'COMPLETED' ? 'text-red-400' : 'text-slate-500'}`}>
              {o.status === 'COMPLETED' ? 'shipped-ready' : o.daysLeft < 0 ? `${-o.daysLeft}d overdue` : `${o.daysLeft}d left`}
            </div>
          </td>
          <td className="td"><StatusBadge status={o.status} /></td>
          <td className="td"><button onClick={() => remove(o)} className="text-slate-500 hover:text-red-400" aria-label="Delete order"><Trash2 size={15} /></button></td>
        </tr>
      ))}
    </>
  );
}
