import { useEffect, useState } from 'react';
import { Trash2 } from 'lucide-react';
import { api, type Order, type ProdRow } from '../api';
import { Empty, Field, Num } from './ui';

interface Props { orders: Order[]; reload: () => void; onError: (m: string) => void; version: number }

const today = () => new Date().toISOString().slice(0, 10);
const blank = { entryDate: today(), fabricReceivedKg: '', cuttingDailyPcs: '', sewingInputDailyPcs: '', sewingOutputDailyPcs: '', finishingPackingDailyPcs: '', lineShift: 'A', remarks: '' };

export default function ProductionTab({ orders, reload, onError, version }: Props) {
  const [orderId, setOrderId] = useState<number | ''>(orders[0]?.id ?? '');
  const [rows, setRows] = useState<ProdRow[]>([]);
  const [f, setF] = useState(blank);

  useEffect(() => { if (orderId === '' && orders.length) setOrderId(orders[0].id); }, [orders, orderId]);
  useEffect(() => {
    if (orderId === '') { setRows([]); return; }
    api.production(orderId).then(setRows).catch((e) => onError(e.message));
  }, [orderId, version]); // eslint-disable-line react-hooks/exhaustive-deps

  const order = orders.find((o) => o.id === orderId);
  const set = (k: keyof typeof blank) => (e: React.ChangeEvent<HTMLInputElement>) => setF({ ...f, [k]: e.target.value });

  async function save(e: React.FormEvent) {
    e.preventDefault();
    if (orderId === '') return;
    const n = (v: string) => Number(v || 0);
    try {
      await api.addProduction({
        orderId, entryDate: f.entryDate, lineShift: f.lineShift, remarks: f.remarks || null,
        fabricReceivedKg: n(f.fabricReceivedKg), cuttingDailyPcs: n(f.cuttingDailyPcs), sewingInputDailyPcs: n(f.sewingInputDailyPcs),
        sewingOutputDailyPcs: n(f.sewingOutputDailyPcs), finishingPackingDailyPcs: n(f.finishingPackingDailyPcs),
      });
      setF({ ...blank, entryDate: f.entryDate, lineShift: f.lineShift });
      reload();
    } catch (err) { onError((err as Error).message); }
  }

  async function remove(id: number) {
    if (!confirm('Delete this daily entry?')) return;
    try { await api.deleteProduction(id); reload(); } catch (err) { onError((err as Error).message); }
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-3">
        <h2 className="text-base font-semibold text-slate-100">Production Tracking</h2>
        <select className="inp !w-auto" value={orderId} onChange={(e) => setOrderId(Number(e.target.value))}>
          {orders.map((o) => <option key={o.id} value={o.id}>{o.buyerName} — {o.styleNo}</option>)}
        </select>
      </div>

      {!order ? <Empty>Create an order first.</Empty> : (
        <>
          <div className="card grid grid-cols-2 gap-x-6 gap-y-2 p-4 text-sm sm:grid-cols-4">
            <Meta k="Buyer" v={order.buyerName} /><Meta k="Style" v={order.styleNo} />
            <Meta k="Item" v={order.itemDescription} /><Meta k="Color / wash" v={order.colorWash} />
            <Meta k="Order qty" v={order.totalOrderQty.toLocaleString()} /><Meta k="Cons. kg/pc" v={String(order.unitConsumptionKg)} />
            <Meta k="Shipment" v={order.shipmentDeadline.slice(0, 10)} /><Meta k="Fabric balance" v={`${order.fabric.balanceKg.toLocaleString()} kg`} />
          </div>

          <div className="grid gap-3 sm:grid-cols-5">
            <Wip label="Cutting balance" v={order.wip.cuttingBalance} />
            <Wip label="Cut → Sew WIP" v={order.wip.cutToSewWip} />
            <Wip label="Sewing floor WIP" v={order.wip.sewingFloorWip} />
            <Wip label="Finishing WIP" v={order.wip.finishingWip} />
            <Wip label="Total floor WIP" v={order.wip.totalFloorWip} strong />
          </div>

          <form onSubmit={save} className="card grid grid-cols-2 gap-3 p-4 sm:grid-cols-4 lg:grid-cols-8">
            <Field label="Date"><input type="date" required className="inp" value={f.entryDate} onChange={set('entryDate')} /></Field>
            <Field label="Shift / line"><input required className="inp" value={f.lineShift} onChange={set('lineShift')} /></Field>
            <Field label="Fabric rcvd kg"><input type="number" step="0.001" min={0} className="inp" value={f.fabricReceivedKg} onChange={set('fabricReceivedKg')} /></Field>
            <Field label="Cutting"><input type="number" min={0} className="inp" value={f.cuttingDailyPcs} onChange={set('cuttingDailyPcs')} /></Field>
            <Field label="Sew input"><input type="number" min={0} className="inp" value={f.sewingInputDailyPcs} onChange={set('sewingInputDailyPcs')} /></Field>
            <Field label="Sew output"><input type="number" min={0} className="inp" value={f.sewingOutputDailyPcs} onChange={set('sewingOutputDailyPcs')} /></Field>
            <Field label="Packed"><input type="number" min={0} className="inp" value={f.finishingPackingDailyPcs} onChange={set('finishingPackingDailyPcs')} /></Field>
            <Field label="Remarks" className="col-span-2 sm:col-span-4 lg:col-span-7"><input className="inp" value={f.remarks} onChange={set('remarks')} /></Field>
            <div className="flex items-end"><button className="btn w-full justify-center">Log entry</button></div>
          </form>

          <div className="card overflow-x-auto">
            <table className="w-full">
              <thead className="border-b border-slate-800">
                <tr>{['Date', 'Shift', 'Fabric kg', 'Cut', 'Sew In', 'Sew Out', 'Packed', 'Σ Cut', 'Σ Sew In', 'Σ Sew Out', 'Σ Packed', 'Floor WIP', 'Remarks', ''].map((h) => <th key={h} className="th">{h}</th>)}</tr>
              </thead>
              <tbody>
                {rows.map((r) => (
                  <tr key={r.id} className="border-b border-slate-800/60 last:border-0 hover:bg-slate-800/30">
                    <td className="td">{r.entryDate.slice(0, 10)}</td><td className="td">{r.lineShift}</td>
                    <td className="td"><Num v={r.fabricReceivedKg} dp={1} /></td>
                    <td className="td"><Num v={r.cuttingDailyPcs} /></td><td className="td"><Num v={r.sewingInputDailyPcs} /></td>
                    <td className="td"><Num v={r.sewingOutputDailyPcs} /></td><td className="td"><Num v={r.finishingPackingDailyPcs} /></td>
                    <td className="td text-slate-400"><Num v={r.cumulative.cut} /></td><td className="td text-slate-400"><Num v={r.cumulative.sewIn} /></td>
                    <td className="td text-slate-400"><Num v={r.cumulative.sewOut} /></td><td className="td text-slate-400"><Num v={r.cumulative.packed} /></td>
                    <td className="td"><Num v={r.wip.totalFloorWip} /></td>
                    <td className="td max-w-[14rem] truncate text-slate-400">{r.remarks}</td>
                    <td className="td"><button onClick={() => remove(r.id)} className="text-slate-500 hover:text-red-400" aria-label="Delete entry"><Trash2 size={15} /></button></td>
                  </tr>
                ))}
              </tbody>
            </table>
            {!rows.length && <Empty>No production logged for this style yet.</Empty>}
          </div>
        </>
      )}
    </div>
  );
}

const Meta = ({ k, v }: { k: string; v: string }) => (
  <div><div className="text-[11px] uppercase tracking-wide text-slate-500">{k}</div><div className="text-slate-100">{v}</div></div>
);
const Wip = ({ label, v, strong }: { label: string; v: number; strong?: boolean }) => (
  <div className={`card p-3 ${strong ? 'border-emerald-500/40' : ''}`}>
    <div className="text-[11px] uppercase tracking-wide text-slate-400">{label}</div>
    <div className={`mt-1 text-xl font-semibold ${v < 0 ? 'text-red-300' : 'text-slate-100'}`}><Num v={v} /></div>
  </div>
);
