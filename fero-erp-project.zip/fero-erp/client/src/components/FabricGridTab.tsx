import { useEffect, useRef, useState } from 'react';
import { ImagePlus, Plus, Trash2 } from 'lucide-react';
import { api, type GridRow, type Order } from '../api';
import { consumptionPerPcKg, convertLength, fabricBalanceKg, round, type Unit } from '../lib/calc';
import { Empty, Num } from './ui';

interface Props { orders: Order[]; reload: () => void; onError: (m: string) => void; version: number }

type NumKey = 'gsm' | 'dia' | 'bodyLength' | 'chestHalf' | 'sleeveLength' | 'wastagePct' | 'fabricReceivedKg' | 'cuttingQtyPcs';
type TextKey = 'fabricType' | 'colorRef' | 'challanNo' | 'remarks';

/** Live values for one row, recomputed on every render from the shared engine. */
const live = (r: GridRow) => {
  const perPc = consumptionPerPcKg(r);
  const fb = fabricBalanceKg(r.fabricReceivedKg, r.cuttingQtyPcs, perPc);
  return { perPc, perDozen: perPc * 12, required: fb.requiredForCut, balance: fb.balance };
};

export default function FabricGridTab({ orders, reload, onError, version }: Props) {
  const [orderId, setOrderId] = useState<number | ''>(orders[0]?.id ?? '');
  const [rows, setRows] = useState<GridRow[]>([]);
  const fileFor = useRef<number | null>(null);
  const fileInput = useRef<HTMLInputElement>(null);

  useEffect(() => { if (orderId === '' && orders.length) setOrderId(orders[0].id); }, [orders, orderId]);
  useEffect(() => {
    if (orderId === '') return;
    api.grid(orderId).then(setRows).catch((e) => onError(e.message));
  }, [orderId, version]); // eslint-disable-line react-hooks/exhaustive-deps

  const unit: Unit = rows[0]?.unit ?? 'CM';
  const upd = (id: number, patch: Partial<GridRow>) => setRows((rs) => rs.map((r) => (r.id === id ? { ...r, ...patch } : r)));
  const fail = (e: unknown) => onError((e as Error).message);

  /** Instant local conversion, then persisted server-side (4 dp). */
  async function toggleUnit(to: Unit) {
    if (orderId === '' || to === unit) return;
    setRows((rs) => rs.map((r) => ({
      ...r, unit: to,
      bodyLength: convertLength(r.bodyLength, r.unit, to),
      chestHalf: convertLength(r.chestHalf, r.unit, to),
      sleeveLength: convertLength(r.sleeveLength, r.unit, to),
    })));
    try { setRows(await api.convertGrid(orderId, to)); } catch (e) { fail(e); if (orderId !== '') setRows(await api.grid(orderId)); }
  }

  async function persist(r: GridRow, key: NumKey | TextKey) {
    try {
      const v = r[key];
      const saved = await api.patchGrid(r.id, { [key]: typeof v === 'string' && v === '' ? null : v });
      upd(r.id, { consumptionPerPcKg: saved.consumptionPerPcKg });
      reload();
    } catch (e) { fail(e); }
  }

  async function addRow() {
    if (orderId === '') return;
    try {
      await api.addGrid({ orderId, fabricType: 'Single Jersey', colorRef: 'TBD', gsm: 180, dia: 76, unit, bodyLength: unit === 'CM' ? 70 : 27.56, chestHalf: unit === 'CM' ? 52 : 20.47, sleeveLength: unit === 'CM' ? 22 : 8.66, wastagePct: 5 });
      setRows(await api.grid(orderId));
    } catch (e) { fail(e); }
  }

  async function remove(id: number) {
    if (!confirm('Delete this fabric row?')) return;
    try { await api.deleteGrid(id); setRows((rs) => rs.filter((r) => r.id !== id)); reload(); } catch (e) { fail(e); }
  }

  async function onFile(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    const id = fileFor.current;
    e.target.value = '';
    if (!file || id == null) return;
    try { const saved = await api.uploadSnapshot(id, file); upd(id, { snapshotImageUrl: saved.snapshotImageUrl }); } catch (err) { fail(err); }
  }

  const numCell = (r: GridRow, k: NumKey, w = 'w-16', step = '0.01') => (
    <input
      type="number" step={step} min={0} value={Number.isFinite(r[k]) ? round(r[k] as number, 4) : ''}
      onChange={(e) => upd(r.id, { [k]: e.target.value === '' ? 0 : Number(e.target.value) })}
      onBlur={() => persist(r, k)}
      className={`inp ${w} !px-1.5 !py-1 text-right font-mono`}
    />
  );
  const textCell = (r: GridRow, k: TextKey, w = 'w-28') => (
    <input value={(r[k] as string | null) ?? ''} onChange={(e) => upd(r.id, { [k]: e.target.value })} onBlur={() => persist(r, k)} className={`inp ${w} !px-1.5 !py-1`} />
  );

  return (
    <div>
      <div className="mb-3 flex flex-wrap items-center gap-3">
        <h2 className="text-base font-semibold text-slate-100">Cutting &amp; Fabric Grid</h2>
        <select className="inp !w-auto" value={orderId} onChange={(e) => setOrderId(Number(e.target.value))}>
          {orders.map((o) => <option key={o.id} value={o.id}>{o.buyerName} — {o.styleNo}</option>)}
        </select>
        <div className="inline-flex overflow-hidden rounded-md border border-slate-700" role="group" aria-label="Unit">
          {(['CM', 'INC'] as Unit[]).map((u) => (
            <button key={u} onClick={() => toggleUnit(u)} className={`px-3 py-1.5 text-sm font-medium ${unit === u ? 'bg-emerald-600 text-white' : 'text-slate-300 hover:bg-slate-800'}`}>{u}</button>
          ))}
        </div>
        <button className="btn ml-auto" onClick={addRow} disabled={orderId === ''}><Plus size={15} /> Add fabric row</button>
      </div>
      <input ref={fileInput} type="file" accept="image/*" className="hidden" onChange={onFile} />

      <div className="card overflow-x-auto">
        <table className="w-full">
          <thead className="border-b border-slate-800">
            <tr>
              {['SL', 'Fabric', 'Color ref', 'GSM', 'Dia', `Body (${unit})`, `Chest ½ (${unit})`, `Sleeve (${unit})`, 'Waste %', 'Rcvd kg', 'Cut pcs', 'Kg/pc', 'Kg/doz', 'Req. for cut', 'Balance kg', 'Challan', 'Snapshot', 'Remarks', ''].map((h) => <th key={h} className="th">{h}</th>)}
            </tr>
          </thead>
          <tbody>
            {rows.map((r) => {
              const c = live(r);
              return (
                <tr key={r.id} className="border-b border-slate-800/60 last:border-0 hover:bg-slate-800/30">
                  <td className="td">{r.slNo}</td>
                  <td className="td">{textCell(r, 'fabricType')}</td>
                  <td className="td">{textCell(r, 'colorRef')}</td>
                  <td className="td">{numCell(r, 'gsm')}</td>
                  <td className="td">{numCell(r, 'dia')}</td>
                  <td className="td">{numCell(r, 'bodyLength', 'w-20')}</td>
                  <td className="td">{numCell(r, 'chestHalf', 'w-20')}</td>
                  <td className="td">{numCell(r, 'sleeveLength', 'w-20')}</td>
                  <td className="td">{numCell(r, 'wastagePct', 'w-14')}</td>
                  <td className="td">{numCell(r, 'fabricReceivedKg', 'w-20', '0.001')}</td>
                  <td className="td">{numCell(r, 'cuttingQtyPcs', 'w-20', '1')}</td>
                  <td className="td font-semibold text-emerald-300"><Num v={c.perPc} dp={4} /></td>
                  <td className="td"><Num v={c.perDozen} dp={3} /></td>
                  <td className="td"><Num v={c.required} dp={1} /></td>
                  <td className="td font-semibold"><Num v={c.balance} dp={1} signed /></td>
                  <td className="td">{textCell(r, 'challanNo', 'w-24')}</td>
                  <td className="td">
                    <button
                      onClick={() => { fileFor.current = r.id; fileInput.current?.click(); }}
                      className="flex h-12 w-12 items-center justify-center overflow-hidden rounded-md border border-dashed border-slate-600 text-slate-500 hover:border-emerald-500 hover:text-emerald-400"
                      aria-label="Upload cutting board / challan snapshot"
                    >
                      {r.snapshotImageUrl ? <img src={r.snapshotImageUrl} alt="Snapshot" className="h-full w-full object-cover" /> : <ImagePlus size={18} />}
                    </button>
                  </td>
                  <td className="td">{textCell(r, 'remarks', 'w-36')}</td>
                  <td className="td"><button onClick={() => remove(r.id)} className="text-slate-500 hover:text-red-400" aria-label="Delete row"><Trash2 size={15} /></button></td>
                </tr>
              );
            })}
          </tbody>
        </table>
        {!rows.length && <Empty>No fabric rows for this style. Add one to start the yield breakdown.</Empty>}
      </div>
      <p className="mt-2 text-xs text-slate-500">
        Kg/pc = ((Body + Sleeve + 10) × (Chest½ + 5) × 2 × GSM ÷ 10,000,000) × (1 + waste%), dimensions in cm. Switching CM/INC converts all dimensions; consumption is unchanged.
      </p>
    </div>
  );
}
