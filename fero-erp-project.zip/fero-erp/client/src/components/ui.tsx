import { X } from 'lucide-react';
import type { ReactNode } from 'react';
import type { OrderStatus } from '../lib/calc';

const STATUS: Record<OrderStatus, { label: string; cls: string }> = {
  NOT_STARTED: { label: 'Not started', cls: 'bg-slate-700/40 text-slate-300 border-slate-600' },
  IN_PRODUCTION: { label: 'In production', cls: 'bg-sky-500/15 text-sky-300 border-sky-500/30' },
  URGENT_DUE: { label: 'Urgent ≤ 7d', cls: 'bg-amber-500/15 text-amber-300 border-amber-500/30' },
  DELAYED_CRITICAL: { label: 'Delayed', cls: 'bg-red-500/15 text-red-300 border-red-500/30' },
  COMPLETED: { label: 'Completed', cls: 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30' },
};

export function StatusBadge({ status }: { status: OrderStatus }) {
  const s = STATUS[status];
  return <span className={`inline-block rounded-full border px-2 py-0.5 text-xs font-medium ${s.cls}`}>{s.label}</span>;
}

export const fmt = (n: number, dp = 0) => n.toLocaleString(undefined, { minimumFractionDigits: dp, maximumFractionDigits: dp });

export function Num({ v, dp = 0, signed = false }: { v: number; dp?: number; signed?: boolean }) {
  const cls = signed ? (v < 0 ? 'text-red-300' : v > 0 ? 'text-emerald-300' : '') : '';
  return <span className={`font-mono tabular-nums ${cls}`}>{fmt(v, dp)}</span>;
}

export function Modal({ title, onClose, children, wide }: { title: string; onClose: () => void; children: ReactNode; wide?: boolean }) {
  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center overflow-y-auto bg-black/70 p-4" onClick={onClose}>
      <div className={`card mt-10 w-full ${wide ? 'max-w-3xl' : 'max-w-xl'} bg-slate-900 p-5`} onClick={(e) => e.stopPropagation()}>
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-lg font-semibold text-slate-100">{title}</h2>
          <button onClick={onClose} className="rounded p-1 text-slate-400 hover:bg-slate-800" aria-label="Close"><X size={18} /></button>
        </div>
        {children}
      </div>
    </div>
  );
}

export function Field({ label, children, className = '' }: { label: string; children: ReactNode; className?: string }) {
  return (
    <label className={className}>
      <span className="lbl">{label}</span>
      {children}
    </label>
  );
}

export function Empty({ children }: { children: ReactNode }) {
  return <div className="px-4 py-10 text-center text-sm text-slate-500">{children}</div>;
}

export function ErrorBar({ msg, onClose }: { msg: string; onClose: () => void }) {
  return (
    <div className="mb-3 flex items-center justify-between rounded-md border border-red-500/30 bg-red-500/10 px-3 py-2 text-sm text-red-300">
      <span>{msg}</span>
      <button onClick={onClose}><X size={14} /></button>
    </div>
  );
}
