import { useState } from 'react';
import { ArrowLeftRight } from 'lucide-react';
import { consumptionPerPcKg, convertLength, kgToLb, lbToKg, round, wovenConsumptionPerPcKg, type Unit } from '../lib/calc';
import { Field, Modal, fmt } from './ui';

type Mode = 'knit' | 'woven';

export default function YieldCalculator({ onClose }: { onClose: () => void }) {
  const [mode, setMode] = useState<Mode>('knit');
  const [unit, setUnit] = useState<Unit>('CM');
  // Keep canonical values in the *current* unit; converting on toggle is lossless (no rounding of state).
  const [v, setV] = useState({ body: 70, chest: 52, sleeve: 22, gsm: 180, waste: 5, markerLen: 600, width: 180, pcs: 8 });
  const [qty, setQty] = useState(1000);
  const [kgIn, setKgIn] = useState(10);
  const [lbIn, setLbIn] = useState(round(kgToLb(10), 4));

  const set = (k: keyof typeof v) => (e: React.ChangeEvent<HTMLInputElement>) => setV({ ...v, [k]: Number(e.target.value) });
  const lenKeys: (keyof typeof v)[] = ['body', 'chest', 'sleeve', 'markerLen', 'width'];

  function switchUnit(to: Unit) {
    if (to === unit) return;
    const next = { ...v };
    for (const k of lenKeys) next[k] = convertLength(v[k], unit, to);
    setV(next);
    setUnit(to);
  }

  const perPc = mode === 'knit'
    ? consumptionPerPcKg({ unit, bodyLength: v.body, chestHalf: v.chest, sleeveLength: v.sleeve, gsm: v.gsm, wastagePct: v.waste })
    : wovenConsumptionPerPcKg({ unit, markerLength: v.markerLen, fabricWidth: v.width, pcsPerMarker: v.pcs, gsm: v.gsm, wastagePct: v.waste });
  const dozen = perPc * 12;
  const total = perPc * qty;

  const num = (k: keyof typeof v, label: string, step = '0.01') => (
    <Field label={label}><input type="number" step={step} min={0} className="inp font-mono" value={round(v[k], 4)} onChange={set(k)} /></Field>
  );

  return (
    <Modal title="Fabric Yield Calculator" onClose={onClose} wide>
      <div className="mb-4 flex flex-wrap items-center gap-3">
        <Seg value={mode} onChange={(m) => setMode(m as Mode)} options={[['knit', 'Knit (T-shirt)'], ['woven', 'Woven (marker)']]} />
        <Seg value={unit} onChange={(u) => switchUnit(u as Unit)} options={[['CM', 'CM'], ['INC', 'INC']]} />
      </div>

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
        {mode === 'knit' ? (<>{num('body', `Body length (${unit})`)}{num('chest', `Chest ½ (${unit})`)}{num('sleeve', `Sleeve length (${unit})`)}</>)
          : (<>{num('markerLen', `Marker length (${unit})`)}{num('width', `Fabric width / dia (${unit})`)}{num('pcs', 'Pcs per marker', '1')}</>)}
        {num('gsm', 'GSM')}
        {num('waste', 'Wastage %')}
        <Field label="Order qty (pcs)"><input type="number" min={0} className="inp font-mono" value={qty} onChange={(e) => setQty(Number(e.target.value))} /></Field>
      </div>

      <div className="mt-5 grid gap-3 sm:grid-cols-4">
        <Out label="Kg / pc" value={fmt(perPc, 4)} accent />
        <Out label="Kg / dozen" value={fmt(dozen, 3)} />
        <Out label={`Total for ${fmt(qty)} pcs (kg)`} value={fmt(total, 1)} />
        <Out label="Total (lbs)" value={fmt(kgToLb(total), 1)} />
      </div>

      <div className="mt-5 flex flex-wrap items-end gap-3 rounded-lg border border-slate-800 p-3">
        <Field label="Kg"><input type="number" step="0.001" className="inp w-32 font-mono" value={kgIn} onChange={(e) => { const k = Number(e.target.value); setKgIn(k); setLbIn(round(kgToLb(k), 4)); }} /></Field>
        <ArrowLeftRight size={18} className="mb-2 text-slate-500" />
        <Field label="Lbs"><input type="number" step="0.001" className="inp w-32 font-mono" value={lbIn} onChange={(e) => { const l = Number(e.target.value); setLbIn(l); setKgIn(round(lbToKg(l), 4)); }} /></Field>
        <span className="mb-2 text-xs text-slate-500">1 kg = 2.20462 lb</span>
      </div>
      {mode === 'knit' && <p className="mt-3 text-xs text-slate-500">((Body + Sleeve + 10) × (Chest½ + 5) × 2 × GSM ÷ 10,000,000) × (1 + waste%) — dimensions evaluated in cm.</p>}
      {mode === 'woven' && <p className="mt-3 text-xs text-slate-500">(Marker length × width × GSM ÷ pcs per marker) × (1 + waste%).</p>}
    </Modal>
  );
}

function Seg({ value, onChange, options }: { value: string; onChange: (v: string) => void; options: [string, string][] }) {
  return (
    <div className="inline-flex overflow-hidden rounded-md border border-slate-700">
      {options.map(([k, l]) => (
        <button key={k} onClick={() => onChange(k)} className={`px-3 py-1.5 text-sm font-medium ${value === k ? 'bg-emerald-600 text-white' : 'text-slate-300 hover:bg-slate-800'}`}>{l}</button>
      ))}
    </div>
  );
}
const Out = ({ label, value, accent }: { label: string; value: string; accent?: boolean }) => (
  <div className={`card p-3 ${accent ? 'border-emerald-500/40' : ''}`}>
    <div className="text-[11px] uppercase tracking-wide text-slate-400">{label}</div>
    <div className="mt-1 font-mono text-xl font-semibold text-slate-100">{value}</div>
  </div>
);
