/**
 * FERO FASHION HOUSE LTD. — Google Apps Script
 * Bind to the spreadsheet created by POST /api/export/sheets (Extensions → Apps Script).
 * Expects tabs: "Master Orders", "Daily Production", "Fabric Recon", "Trims".
 *
 * Setup: set ALERT_EMAILS below, run onOpen once to authorise, then run installTriggers().
 */
const CONFIG = {
  ALERT_EMAILS: 'merchandising@example.com,planning@example.com', // comma separated
  URGENT_DAYS: 7,
  TZ: 'Asia/Dhaka',
};

function onOpen() {
  SpreadsheetApp.getUi()
    .createMenu('FERO ERP')
    .addItem('Check shipment deadlines', 'checkShipmentDeadlines')
    .addItem('Audit fabric shortage', 'auditFabricShortage')
    .addItem('Send daily production digest', 'sendDailyProductionDigest')
    .addSeparator()
    .addItem('Install daily triggers', 'installTriggers')
    .addToUi();
}

/** Reads a tab into an array of objects keyed by header. */
function readTab_(name) {
  const sh = SpreadsheetApp.getActive().getSheetByName(name);
  if (!sh || sh.getLastRow() < 2) return [];
  const [head, ...rows] = sh.getDataRange().getValues();
  return rows.map((r) => Object.fromEntries(head.map((h, i) => [h, r[i]])));
}

function mail_(subject, html) {
  MailApp.sendEmail({ to: CONFIG.ALERT_EMAILS, subject: '[FERO ERP] ' + subject, htmlBody: html });
}

function table_(headers, rows) {
  const th = headers.map((h) => '<th style="border:1px solid #ccc;padding:4px 8px;background:#f1f1f1">' + h + '</th>').join('');
  const tr = rows.map((r) => '<tr>' + r.map((c) => '<td style="border:1px solid #ccc;padding:4px 8px">' + c + '</td>').join('') + '</tr>').join('');
  return '<table style="border-collapse:collapse;font-family:Arial;font-size:13px"><tr>' + th + '</tr>' + tr + '</table>';
}

/** Highlights rows and emails a list of orders that are overdue or due within URGENT_DAYS. */
function checkShipmentDeadlines() {
  const sh = SpreadsheetApp.getActive().getSheetByName('Master Orders');
  if (!sh || sh.getLastRow() < 2) return;
  const data = sh.getDataRange().getValues();
  const head = data[0];
  const col = (n) => head.indexOf(n);
  const today = new Date(Utilities.formatDate(new Date(), CONFIG.TZ, 'yyyy-MM-dd') + 'T00:00:00');
  const alerts = [];

  for (let i = 1; i < data.length; i++) {
    const r = data[i];
    const status = r[col('Status')];
    const range = sh.getRange(i + 1, 1, 1, head.length);
    if (status === 'COMPLETED') { range.setBackground('#d9ead3'); continue; }
    const dl = new Date(r[col('Shipment Deadline')]);
    const days = Math.round((dl - today) / 86400000);
    if (days < 0) { range.setBackground('#f4cccc'); alerts.push([r[col('Buyer')], r[col('Style No')], Utilities.formatDate(dl, CONFIG.TZ, 'dd MMM yyyy'), days + ' d (OVERDUE)', r[col('Order Qty')] - r[col('Packed')]]); }
    else if (days <= CONFIG.URGENT_DAYS) { range.setBackground('#fff2cc'); alerts.push([r[col('Buyer')], r[col('Style No')], Utilities.formatDate(dl, CONFIG.TZ, 'dd MMM yyyy'), days + ' d', r[col('Order Qty')] - r[col('Packed')]]); }
    else range.setBackground(null);
  }
  if (alerts.length) {
    mail_('Shipment deadline alert (' + alerts.length + ')', '<p>Orders overdue or due within ' + CONFIG.URGENT_DAYS + ' days:</p>' + table_(['Buyer', 'Style', 'Deadline', 'Days left', 'Pcs to pack'], alerts));
  }
}

/** Emails buyers whose received fabric is below requirement. */
function auditFabricShortage() {
  const short = readTab_('Fabric Recon').filter((r) => Number(r['Shortage Kg']) > 0);
  if (!short.length) return;
  const rows = short.map((r) => [r['Buyer'], r['Styles'], r['Required Kg'], r['Received Kg'], r['Shortage Kg'], '≈ ' + r['Est. Short Pcs'] + ' pcs']);
  mail_('Fabric shortage audit (' + short.length + ' buyer' + (short.length > 1 ? 's' : '') + ')', table_(['Buyer', 'Styles', 'Required Kg', 'Received Kg', 'Shortage Kg', 'Garment impact'], rows));

  const sh = SpreadsheetApp.getActive().getSheetByName('Fabric Recon');
  const head = sh.getRange(1, 1, 1, sh.getLastColumn()).getValues()[0];
  const c = head.indexOf('Shortage Kg') + 1;
  const vals = sh.getRange(2, c, sh.getLastRow() - 1, 1).getValues();
  vals.forEach((v, i) => sh.getRange(i + 2, c).setBackground(Number(v[0]) > 0 ? '#f4cccc' : null));
}

/** Yesterday's (or latest day's) production totals by style. */
function sendDailyProductionDigest() {
  const rows = readTab_('Daily Production');
  if (!rows.length) return;
  const fmt = (d) => Utilities.formatDate(new Date(d), CONFIG.TZ, 'yyyy-MM-dd');
  const latest = rows.map((r) => fmt(r['Date'])).sort().pop();
  const day = rows.filter((r) => fmt(r['Date']) === latest);
  const by = {};
  day.forEach((r) => {
    const k = r['Buyer'] + ' | ' + r['Style No'];
    const t = (by[k] = by[k] || [r['Buyer'], r['Style No'], 0, 0, 0, 0]);
    t[2] += Number(r['Cutting']); t[3] += Number(r['Sew Input']); t[4] += Number(r['Sew Output']); t[5] += Number(r['Packed']);
  });
  const lines = Object.values(by);
  const tot = lines.reduce((a, r) => [a[0] + r[2], a[1] + r[3], a[2] + r[4], a[3] + r[5]], [0, 0, 0, 0]);
  lines.push(['<b>TOTAL</b>', '', '<b>' + tot[0] + '</b>', '<b>' + tot[1] + '</b>', '<b>' + tot[2] + '</b>', '<b>' + tot[3] + '</b>']);
  mail_('Daily production digest — ' + latest, table_(['Buyer', 'Style', 'Cutting', 'Sew In', 'Sew Out', 'Packed'], lines));
}

/** One-time: run these checks every morning (8–9am script time zone). */
function installTriggers() {
  ScriptApp.getProjectTriggers().forEach((t) => ScriptApp.deleteTrigger(t));
  ScriptApp.newTrigger('checkShipmentDeadlines').timeBased().everyDays(1).atHour(8).create();
  ScriptApp.newTrigger('auditFabricShortage').timeBased().everyDays(1).atHour(8).create();
  ScriptApp.newTrigger('sendDailyProductionDigest').timeBased().everyDays(1).atHour(9).create();
  SpreadsheetApp.getActive().toast('Daily triggers installed', 'FERO ERP');
}
