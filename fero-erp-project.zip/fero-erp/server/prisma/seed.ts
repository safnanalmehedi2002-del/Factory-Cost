import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();
const day = (offset: number) => {
  const d = new Date();
  d.setUTCDate(d.getUTCDate() + offset);
  return new Date(d.toISOString().slice(0, 10));
};

async function main() {
  await prisma.dailyProduction.deleteMany();
  await prisma.cuttingFabricGrid.deleteMany();
  await prisma.trimsInventory.deleteMany();
  await prisma.masterOrder.deleteMany();

  const mk = (buyerName: string, styleNo: string, itemDescription: string, colorWash: string, qty: number, cons: number, deadline: number) =>
    prisma.masterOrder.create({ data: { buyerName, styleNo, itemDescription, colorWash, totalOrderQty: qty, unitConsumptionKg: cons, shipmentDeadline: day(deadline) } });

  const a = await mk('H&M', 'HM-24501', 'Basic Crew Neck T-Shirt', 'Navy', 12000, 0.22, 30);
  const b = await mk('H&M', 'HM-24577', 'Henley Long Sleeve', 'Off White', 6000, 0.31, 5);
  const c = await mk('Zara', 'ZR-88120', 'Polo Shirt', 'Stone Wash', 8000, 0.28, -3);
  const d = await mk('Primark', 'PM-1002', 'Kids Tee', 'Assorted', 5000, 0.15, 60);

  for (let i = 10; i >= 1; i--) {
    await prisma.dailyProduction.create({ data: { orderId: a.id, entryDate: day(-i), fabricReceivedKg: i === 10 ? 2200 : 0, cuttingDailyPcs: 500 + i * 10, sewingInputDailyPcs: 420 + i * 10, sewingOutputDailyPcs: 380 + i * 8, finishingPackingDailyPcs: 300 + i * 5, lineShift: 'A', remarks: i === 1 ? 'Line 3 machine down 1h' : null } });
  }
  for (let i = 6; i >= 1; i--) {
    await prisma.dailyProduction.create({ data: { orderId: b.id, entryDate: day(-i), fabricReceivedKg: i === 6 ? 1500 : 0, cuttingDailyPcs: 600, sewingInputDailyPcs: 550, sewingOutputDailyPcs: 500, finishingPackingDailyPcs: 450, lineShift: 'B' } });
  }
  await prisma.dailyProduction.create({ data: { orderId: c.id, entryDate: day(-4), fabricReceivedKg: 1800, cuttingDailyPcs: 3000, sewingInputDailyPcs: 2500, sewingOutputDailyPcs: 2000, finishingPackingDailyPcs: 1500, lineShift: 'A' } });

  const kg = (r: { unit: 'CM' | 'INC'; b: number; c: number; s: number; gsm: number; w: number }) => {
    const cm = (v: number) => (r.unit === 'INC' ? v * 2.54 : v);
    return Math.round(((cm(r.b) + cm(r.s) + 10) * (cm(r.c) + 5) * 2 * r.gsm / 1e7) * (1 + r.w / 100) * 1e5) / 1e5;
  };
  const g1 = { unit: 'CM' as const, b: 70, c: 52, s: 22, gsm: 180, w: 5 };
  const g2 = { unit: 'INC' as const, b: 27.5, c: 20.5, s: 8.5, gsm: 160, w: 6 };
  await prisma.cuttingFabricGrid.createMany({
    data: [
      { orderId: a.id, slNo: 1, fabricType: 'Single Jersey', colorRef: 'Navy 19-3921', gsm: 180, dia: 76, unit: 'CM', bodyLength: 70, chestHalf: 52, sleeveLength: 22, wastagePct: 5, fabricReceivedKg: 2200, cuttingQtyPcs: 5100, consumptionPerPcKg: kg(g1), challanNo: 'CH-0091' },
      { orderId: b.id, slNo: 1, fabricType: 'Slub Jersey', colorRef: 'Off White', gsm: 160, dia: 30, unit: 'INC', bodyLength: 27.5, chestHalf: 20.5, sleeveLength: 8.5, wastagePct: 6, fabricReceivedKg: 1500, cuttingQtyPcs: 3600, consumptionPerPcKg: kg(g2), challanNo: 'CH-0102' },
    ],
  });

  await prisma.trimsInventory.createMany({
    data: [
      { orderId: a.id, itemDescription: 'Sewing Thread 40/2 Navy', category: 'SEWING_TRIMS', unit: 'CONES', totalRequired: 300, totalReceived: 280, totalUsed: 240, minBufferThreshold: 50 },
      { orderId: a.id, itemDescription: 'Main Label (woven)', category: 'LABELS_TAGS', unit: 'PCS', totalRequired: 12200, totalReceived: 12200, totalUsed: 5100, minBufferThreshold: 500 },
      { orderId: b.id, itemDescription: 'Polybag 12x16', category: 'PACKING_TRIMS', unit: 'PCS', totalRequired: 6100, totalReceived: 3000, totalUsed: 2900, minBufferThreshold: 300 },
      { orderId: b.id, itemDescription: 'Carton 5-ply', category: 'PACKING_TRIMS', unit: 'PCS', totalRequired: 250, totalReceived: 250, totalUsed: 30, minBufferThreshold: 20 },
    ],
  });
  console.log('Seeded demo data');
}

main().finally(() => prisma.$disconnect());
