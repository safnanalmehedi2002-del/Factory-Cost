-- CreateEnum
CREATE TYPE "OrderStatus" AS ENUM ('NOT_STARTED', 'IN_PRODUCTION', 'URGENT_DUE', 'DELAYED_CRITICAL', 'COMPLETED');
CREATE TYPE "LengthUnit" AS ENUM ('CM', 'INC');
CREATE TYPE "TrimCategory" AS ENUM ('SEWING_TRIMS', 'PACKING_TRIMS', 'LABELS_TAGS');
CREATE TYPE "TrimUnit" AS ENUM ('PCS', 'GROSS', 'YARDS', 'CONES', 'SETS');

-- CreateTable
CREATE TABLE "master_orders" (
    "id" SERIAL NOT NULL,
    "buyer_name" TEXT NOT NULL,
    "style_no" TEXT NOT NULL,
    "item_description" TEXT NOT NULL,
    "color_wash" TEXT NOT NULL,
    "total_order_qty" INTEGER NOT NULL,
    "unit_consumption_kg" DECIMAL(10,4) NOT NULL,
    "shipment_deadline" DATE NOT NULL,
    "status" "OrderStatus" NOT NULL DEFAULT 'NOT_STARTED',
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,
    CONSTRAINT "master_orders_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "daily_production" (
    "id" SERIAL NOT NULL,
    "order_id" INTEGER NOT NULL,
    "entry_date" DATE NOT NULL,
    "fabric_received_kg" DECIMAL(12,3) NOT NULL DEFAULT 0,
    "cutting_daily_pcs" INTEGER NOT NULL DEFAULT 0,
    "sewing_input_daily_pcs" INTEGER NOT NULL DEFAULT 0,
    "sewing_output_daily_pcs" INTEGER NOT NULL DEFAULT 0,
    "finishing_packing_daily_pcs" INTEGER NOT NULL DEFAULT 0,
    "line_shift" TEXT NOT NULL DEFAULT 'A',
    "remarks" TEXT,
    CONSTRAINT "daily_production_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "cutting_fabric_grid" (
    "id" SERIAL NOT NULL,
    "order_id" INTEGER NOT NULL,
    "sl_no" INTEGER NOT NULL,
    "fabric_type" TEXT NOT NULL,
    "color_ref" TEXT NOT NULL,
    "gsm" DECIMAL(8,2) NOT NULL,
    "dia" DECIMAL(8,2) NOT NULL,
    "unit" "LengthUnit" NOT NULL DEFAULT 'CM',
    "body_length" DECIMAL(10,4) NOT NULL,
    "chest_half" DECIMAL(10,4) NOT NULL,
    "sleeve_length" DECIMAL(10,4) NOT NULL,
    "wastage_pct" DECIMAL(6,2) NOT NULL,
    "fabric_received_kg" DECIMAL(12,3) NOT NULL DEFAULT 0,
    "cutting_qty_pcs" INTEGER NOT NULL DEFAULT 0,
    "consumption_per_pc_kg" DECIMAL(10,5) NOT NULL DEFAULT 0,
    "challan_no" TEXT,
    "snapshot_image_url" TEXT,
    "remarks" TEXT,
    CONSTRAINT "cutting_fabric_grid_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "trims_inventory" (
    "id" SERIAL NOT NULL,
    "order_id" INTEGER NOT NULL,
    "item_description" TEXT NOT NULL,
    "category" "TrimCategory" NOT NULL,
    "unit" "TrimUnit" NOT NULL,
    "total_required" DECIMAL(12,2) NOT NULL DEFAULT 0,
    "total_received" DECIMAL(12,2) NOT NULL DEFAULT 0,
    "total_used" DECIMAL(12,2) NOT NULL DEFAULT 0,
    "min_buffer_threshold" DECIMAL(12,2) NOT NULL DEFAULT 0,
    CONSTRAINT "trims_inventory_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "master_orders_style_no_key" ON "master_orders"("style_no");
CREATE INDEX "master_orders_buyer_name_idx" ON "master_orders"("buyer_name");
CREATE INDEX "daily_production_order_id_entry_date_idx" ON "daily_production"("order_id", "entry_date");
CREATE INDEX "cutting_fabric_grid_order_id_idx" ON "cutting_fabric_grid"("order_id");
CREATE INDEX "trims_inventory_order_id_idx" ON "trims_inventory"("order_id");

-- AddForeignKey
ALTER TABLE "daily_production" ADD CONSTRAINT "daily_production_order_id_fkey" FOREIGN KEY ("order_id") REFERENCES "master_orders"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "cutting_fabric_grid" ADD CONSTRAINT "cutting_fabric_grid_order_id_fkey" FOREIGN KEY ("order_id") REFERENCES "master_orders"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "trims_inventory" ADD CONSTRAINT "trims_inventory_order_id_fkey" FOREIGN KEY ("order_id") REFERENCES "master_orders"("id") ON DELETE CASCADE ON UPDATE CASCADE;
