import { google } from 'googleapis';
import { buildOrderSummaries, buildReconciliation, buildTrims } from '../lib/summary.js';
import { prisma, num } from '../db.js';
import { HttpError } from '../lib/http.js';

/**
 * Service-account auth. Provide either
 *   GOOGLE_SERVICE_ACCOUNT_JSON  (the full JSON, single line)  or
 *   GOOGLE_SERVICE_ACCOUNT_EMAIL + GOOGLE_PRIVATE_KEY (with \n escapes)
 */
function auth() {
  const json = process.env.GOOGLE_SERVICE_ACCOUNT_JSON;
  const scopes = ['https://www.googleapis.com/auth/spreadsheets', 'https://www.googleapis.com/auth/drive'];
  if (json) return new google.auth.GoogleAuth({ credentials: JSON.parse(json), scopes });
  const email = process.env.GOOGLE_SERVICE_ACCOUNT_EMAIL;
  const key = process.env.GOOGLE_PRIVATE_KEY?.replace(/\\n/g, '\n');
  if (!email || !key) throw new HttpError(503, 'Google export is not configured (set GOOGLE_SERVICE_ACCOUNT_JSON). See README.');
  return new google.auth.JWT({ email, key, scopes });
}

const iso = (d: Date | string) => new Date(d).toISOString().slice(0, 10);

async function collect(): Promise<Record<string, (string | number)[][]>> {
  const [orders, recon, trims, prod, grid] = await Promise.all([
    buildOrderSummaries(),
    buildReconciliation(),
    buildTrims(),
    prisma.dailyProduction.findMany({ include: { order: true }, orderBy: [{ entryDate: 'desc' }, { id: 'desc' }] }),
    prisma.cuttingFabricGrid.findMany({ include: { order: true }, orderBy: [{ orderId: 'asc' }, { slNo: 'asc' }] }),
  ]);
  return {
    'Master Orders': [
      ['Buyer', 'Style No', 'Item', 'Color/Wash', 'Order Qty', 'Cons Kg/Pc', 'Shipment Deadline', 'Days Left', 'Status', 'Cut', 'Sew In', 'Sew Out', 'Packed', 'Cut Balance', 'Floor WIP'],
      ...orders.map((o) => [o.buyerName, o.styleNo, o.itemDescription, o.colorWash, o.totalOrderQty, o.unitConsumptionKg, iso(o.shipmentDeadline), o.daysLeft, o.status, o.cumulative.cut, o.cumulative.sewIn, o.cumulative.sewOut, o.cumulative.packed, o.wip.cuttingBalance, o.wip.totalFloorWip]),
    ],
    'Daily Production': [
      ['Date', 'Buyer', 'Style No', 'Shift', 'Fabric Rcvd Kg', 'Cutting', 'Sew Input', 'Sew Output', 'Packed', 'Remarks'],
      ...prod.map((p) => [iso(p.entryDate), p.order.buyerName, p.order.styleNo, p.lineShift, num(p.fabricReceivedKg), p.cuttingDailyPcs, p.sewingInputDailyPcs, p.sewingOutputDailyPcs, p.finishingPackingDailyPcs, p.remarks ?? '']),
    ],
    'Cutting & Fabric': [
      ['Style No', 'SL', 'Fabric', 'Color', 'GSM', 'Dia', 'Unit', 'Body', 'Chest(1/2)', 'Sleeve', 'Wastage %', 'Rcvd Kg', 'Cut Pcs', 'Kg/Pc', 'Challan', 'Remarks'],
      ...grid.map((g) => [g.order.styleNo, g.slNo, g.fabricType, g.colorRef, num(g.gsm), num(g.dia), g.unit, num(g.bodyLength), num(g.chestHalf), num(g.sleeveLength), num(g.wastagePct), num(g.fabricReceivedKg), g.cuttingQtyPcs, num(g.consumptionPerPcKg), g.challanNo ?? '', g.remarks ?? '']),
    ],
    'Fabric Recon': [
      ['Buyer', 'Styles', 'Required Kg', 'Received Kg', 'Shortage Kg', 'Excess Kg', 'Avg Kg/Pc', 'Est. Short Pcs', 'Est. Excess Pcs'],
      ...recon.buyers.map((b) => [b.buyer, b.styles.join(', '), b.requiredKg, b.receivedKg, b.shortageKg, b.excessKg, b.avgConsumptionKg, b.shortagePcs, b.excessPcs]),
    ],
    Trims: [
      ['Buyer', 'Style No', 'Item', 'Category', 'Unit', 'Required', 'Received', 'Used', 'Balance', 'Min Buffer', 'Reorder?'],
      ...trims.map((t) => [t.buyerName, t.styleNo, t.itemDescription, t.category, t.unit, t.totalRequired, t.totalReceived, t.totalUsed, t.balance, t.minBufferThreshold, t.lowStock ? 'YES' : '']),
    ],
  };
}

export async function exportToSheets(opts: { title?: string; shareWith?: string[]; spreadsheetId?: string }) {
  const a = auth();
  const sheets = google.sheets({ version: 'v4', auth: a });
  const drive = google.drive({ version: 'v3', auth: a });
  const data = await collect();
  const names = Object.keys(data);

  let id = opts.spreadsheetId;
  if (!id) {
    const created = await sheets.spreadsheets.create({
      requestBody: {
        properties: { title: opts.title ?? `FERO FASHION HOUSE LTD. – ERP Export ${iso(new Date())}` },
        sheets: names.map((title) => ({ properties: { title, gridProperties: { frozenRowCount: 1 } } })),
      },
    });
    id = created.data.spreadsheetId!;
  } else {
    const meta = await sheets.spreadsheets.get({ spreadsheetId: id });
    const have = new Set(meta.data.sheets?.map((s) => s.properties?.title));
    const add = names.filter((n) => !have.has(n));
    if (add.length) {
      await sheets.spreadsheets.batchUpdate({ spreadsheetId: id, requestBody: { requests: add.map((title) => ({ addSheet: { properties: { title } } })) } });
    }
    await sheets.spreadsheets.values.batchClear({ spreadsheetId: id, requestBody: { ranges: names.map((n) => `'${n}'`) } });
  }

  await sheets.spreadsheets.values.batchUpdate({
    spreadsheetId: id,
    requestBody: { valueInputOption: 'USER_ENTERED', data: names.map((n) => ({ range: `'${n}'!A1`, values: data[n] })) },
  });

  for (const email of opts.shareWith ?? []) {
    await drive.permissions.create({ fileId: id, requestBody: { type: 'user', role: 'writer', emailAddress: email } });
  }
  return { spreadsheetId: id, url: `https://docs.google.com/spreadsheets/d/${id}/edit`, tabs: names.map((n) => ({ name: n, rows: data[n].length - 1 })) };
}
