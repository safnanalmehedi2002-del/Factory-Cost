import { describe, it, expect } from 'vitest';
import {
  consumptionPerPcKg,
  consumptionPerDozenKg,
  convertLength,
  computeWip,
  reconcile,
  deriveStatus,
  fabricBalanceKg,
  wovenConsumptionPerPcKg,
  trimsStatus,
} from './calc.js';

const base = { unit: 'CM' as const, bodyLength: 70, chestHalf: 52, sleeveLength: 22, gsm: 180, wastagePct: 5 };

describe('knit consumption', () => {
  it('matches hand calculation (0.2198 kg/pc)', () => {
    expect(consumptionPerPcKg(base)).toBeCloseTo(0.219769, 5);
  });
  it('dozen = pc * 12', () => {
    expect(consumptionPerDozenKg(base)).toBeCloseTo(consumptionPerPcKg(base) * 12, 10);
  });
  it('INC and CM inputs give identical result', () => {
    const inc = {
      ...base,
      unit: 'INC' as const,
      bodyLength: convertLength(70, 'CM', 'INC'),
      chestHalf: convertLength(52, 'CM', 'INC'),
      sleeveLength: convertLength(22, 'CM', 'INC'),
    };
    expect(consumptionPerPcKg(inc)).toBeCloseTo(consumptionPerPcKg(base), 10);
  });
  it('round-trip CM->INC->CM is lossless to float precision', () => {
    expect(convertLength(convertLength(68.58, 'CM', 'INC'), 'INC', 'CM')).toBeCloseTo(68.58, 12);
  });
});

describe('woven', () => {
  it('computes kg/pc from marker', () => {
    // 5m x 1.5m x 150gsm = 1.125kg / 6pcs = 0.1875 * 1.05
    const v = wovenConsumptionPerPcKg({ unit: 'CM', markerLength: 500, fabricWidth: 150, pcsPerMarker: 6, gsm: 150, wastagePct: 5 });
    expect(v).toBeCloseTo(0.196875, 6);
  });
});

describe('wip & balances', () => {
  it('computes all WIP buckets', () => {
    const w = computeWip({ orderQty: 1000, cut: 800, sewIn: 600, sewOut: 400, packed: 100 });
    expect(w).toEqual({ cuttingBalance: 200, cutToSewWip: 200, sewingFloorWip: 200, finishingWip: 300, totalFloorWip: 700 });
  });
  it('fabric balance', () => {
    const f = fabricBalanceKg(500, 1000, 0.4);
    expect(f.requiredForCut).toBeCloseTo(400);
    expect(f.balance).toBeCloseTo(100);
  });
});

describe('reconciliation', () => {
  it('shortage', () => {
    const r = reconcile(1000, 900, 0.25);
    expect(r).toMatchObject({ shortageKg: 100, excessKg: 0, shortagePcs: 400 });
  });
  it('excess', () => {
    const r = reconcile(900, 1000, 0.25);
    expect(r).toMatchObject({ shortageKg: 0, excessKg: 100, excessPcs: 400 });
  });
});

describe('status', () => {
  const today = new Date('2026-10-19T00:00:00Z');
  it('completed', () => expect(deriveStatus({ orderQty: 10, cut: 10, packed: 10, deadline: '2026-01-01' }, today)).toBe('COMPLETED'));
  it('delayed', () => expect(deriveStatus({ orderQty: 10, cut: 5, packed: 0, deadline: '2026-10-18' }, today)).toBe('DELAYED_CRITICAL'));
  it('urgent within 7 days', () => expect(deriveStatus({ orderQty: 10, cut: 5, packed: 0, deadline: '2026-10-26' }, today)).toBe('URGENT_DUE'));
  it('in production', () => expect(deriveStatus({ orderQty: 10, cut: 5, packed: 0, deadline: '2026-10-27' }, today)).toBe('IN_PRODUCTION'));
  it('not started', () => expect(deriveStatus({ orderQty: 10, cut: 0, packed: 0, deadline: '2026-12-01' }, today)).toBe('NOT_STARTED'));
});

describe('trims', () => {
  it('flags low stock', () => {
    expect(trimsStatus({ received: 1000, used: 900, minBuffer: 200, required: 1200 })).toMatchObject({ balance: 100, lowStock: true, shortToRequirement: 200 });
  });
});
