import { prisma, num } from '../db.js';
import { computeWip, deriveStatus, fabricBalanceKg, reconcile, round, daysUntil, trimsStatus } from './calc.js';

/**
 * Data-source rules (documented in README):
 *  - Cumulative cut / sew / pack quantities come from daily_production.
 *  - Fabric received = SUM(cutting_fabric_grid.fabric_received_kg) when the order has grid rows
 *    (challan-backed); otherwise SUM(daily_production.fabric_received_kg).
 *  - Consumption per pc = order.unit_consumption_kg (the buying/budget figure).
 */
export async function buildOrderSummaries(orderId?: number) {
  const where = orderId ? { id: orderId } : {};
  const orders = await prisma.masterOrder.findMany({ where, orderBy: { shipmentDeadline: 'asc' } });
  const ids = orders.map((o) => o.id);

  const [prod, grid] = await Promise.all([
    prisma.dailyProduction.groupBy({
      by: ['orderId'],
      where: { orderId: { in: ids } },
      _sum: {
        fabricReceivedKg: true,
        cuttingDailyPcs: true,
        sewingInputDailyPcs: true,
        sewingOutputDailyPcs: true,
        finishingPackingDailyPcs: true,
      },
    }),
    prisma.cuttingFabricGrid.groupBy({
      by: ['orderId'],
      where: { orderId: { in: ids } },
      _sum: { fabricReceivedKg: true },
      _count: true,
    }),
  ]);
  const prodMap = new Map(prod.map((p) => [p.orderId, p._sum]));
  const gridMap = new Map(grid.map((g) => [g.orderId, g]));

  const summaries = orders.map((o) => {
    const p = prodMap.get(o.id);
    const g = gridMap.get(o.id);
    const cut = p?.cuttingDailyPcs ?? 0;
    const sewIn = p?.sewingInputDailyPcs ?? 0;
    const sewOut = p?.sewingOutputDailyPcs ?? 0;
    const packed = p?.finishingPackingDailyPcs ?? 0;
    const cons = num(o.unitConsumptionKg);
    const received = g && g._count > 0 ? num(g._sum.fabricReceivedKg) : num(p?.fabricReceivedKg);
    const requiredTotal = o.totalOrderQty * cons;
    const status = deriveStatus({ orderQty: o.totalOrderQty, cut, packed, deadline: o.shipmentDeadline });
    const fb = fabricBalanceKg(received, cut, cons);
    return {
      id: o.id,
      buyerName: o.buyerName,
      styleNo: o.styleNo,
      itemDescription: o.itemDescription,
      colorWash: o.colorWash,
      totalOrderQty: o.totalOrderQty,
      unitConsumptionKg: cons,
      shipmentDeadline: o.shipmentDeadline,
      daysLeft: daysUntil(o.shipmentDeadline),
      storedStatus: o.status,
      status,
      cumulative: { cut, sewIn, sewOut, packed },
      wip: computeWip({ orderQty: o.totalOrderQty, cut, sewIn, sewOut, packed }),
      fabric: {
        receivedKg: round(received, 3),
        requiredTotalKg: round(requiredTotal, 3),
        requiredForCutKg: round(fb.requiredForCut, 3),
        balanceKg: round(fb.balance, 3),
      },
    };
  });

  // Persist derived status so the stored column (and exports) stay current.
  const stale = summaries.filter((s) => s.status !== s.storedStatus);
  if (stale.length) {
    await prisma.$transaction(
      stale.map((s) => prisma.masterOrder.update({ where: { id: s.id }, data: { status: s.status } })),
    );
  }
  return summaries;
}

export async function buildReconciliation() {
  const orders = await buildOrderSummaries();
  const byBuyer = new Map<string, { buyer: string; styles: string[]; required: number; received: number; qty: number }>();
  for (const o of orders) {
    const b = byBuyer.get(o.buyerName) ?? { buyer: o.buyerName, styles: [], required: 0, received: 0, qty: 0 };
    b.styles.push(o.styleNo);
    b.required += o.fabric.requiredTotalKg;
    b.received += o.fabric.receivedKg;
    b.qty += o.totalOrderQty;
    byBuyer.set(o.buyerName, b);
  }
  const buyers = [...byBuyer.values()].map((b) => {
    const avgCons = b.qty ? b.required / b.qty : 0; // weighted average kg/pc
    const r = reconcile(b.required, b.received, avgCons);
    return {
      buyer: b.buyer,
      styles: b.styles,
      requiredKg: round(b.required, 3),
      receivedKg: round(b.received, 3),
      avgConsumptionKg: round(avgCons, 4),
      ...r,
      shortageKg: round(r.shortageKg, 3),
      excessKg: round(r.excessKg, 3),
    };
  });
  const styles = orders.map((o) => {
    const r = reconcile(o.fabric.requiredTotalKg, o.fabric.receivedKg, o.unitConsumptionKg);
    return {
      orderId: o.id,
      buyer: o.buyerName,
      styleNo: o.styleNo,
      requiredKg: o.fabric.requiredTotalKg,
      receivedKg: o.fabric.receivedKg,
      ...r,
      shortageKg: round(r.shortageKg, 3),
      excessKg: round(r.excessKg, 3),
    };
  });
  return { buyers, styles };
}

export async function buildTrims(orderId?: number) {
  const rows = await prisma.trimsInventory.findMany({
    where: orderId ? { orderId } : {},
    include: { order: { select: { buyerName: true, styleNo: true } } },
    orderBy: [{ orderId: 'asc' }, { category: 'asc' }, { id: 'asc' }],
  });
  return rows.map((t) => ({
    id: t.id,
    orderId: t.orderId,
    buyerName: t.order.buyerName,
    styleNo: t.order.styleNo,
    itemDescription: t.itemDescription,
    category: t.category,
    unit: t.unit,
    totalRequired: num(t.totalRequired),
    totalReceived: num(t.totalReceived),
    totalUsed: num(t.totalUsed),
    minBufferThreshold: num(t.minBufferThreshold),
    ...trimsStatus({
      required: num(t.totalRequired),
      received: num(t.totalReceived),
      used: num(t.totalUsed),
      minBuffer: num(t.minBufferThreshold),
    }),
  }));
}

export async function buildDashboard() {
  const [orders, recon, trims] = await Promise.all([buildOrderSummaries(), buildReconciliation(), buildTrims()]);
  const active = orders.filter((o) => o.status !== 'COMPLETED');
  const delayed = orders.filter((o) => o.status === 'DELAYED_CRITICAL').length;
  const urgent = orders.filter((o) => o.status === 'URGENT_DUE').length;
  const shortBuyers = recon.buyers.filter((b) => b.shortageKg > 0).length;
  const lowTrims = trims.filter((t) => t.lowStock).length;
  return {
    totalOrderQty: orders.reduce((s, o) => s + o.totalOrderQty, 0),
    totalCut: orders.reduce((s, o) => s + o.cumulative.cut, 0),
    totalPacked: orders.reduce((s, o) => s + o.cumulative.packed, 0),
    activeFloorWip: active.reduce((s, o) => s + o.wip.totalFloorWip, 0),
    criticalAlerts: { total: delayed + urgent + shortBuyers + lowTrims, delayed, urgent, fabricShortage: shortBuyers, lowTrims },
  };
}
