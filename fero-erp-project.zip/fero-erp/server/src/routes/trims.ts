import { Router } from 'express';
import { z } from 'zod';
import { prisma } from '../db.js';
import { ah, idParam } from '../lib/http.js';
import { buildTrims } from '../lib/summary.js';

export const trims = Router();

const body = z.object({
  orderId: z.number().int().positive(),
  itemDescription: z.string().min(1),
  category: z.enum(['SEWING_TRIMS', 'PACKING_TRIMS', 'LABELS_TAGS']),
  unit: z.enum(['PCS', 'GROSS', 'YARDS', 'CONES', 'SETS']),
  totalRequired: z.number().nonnegative().default(0),
  totalReceived: z.number().nonnegative().default(0),
  totalUsed: z.number().nonnegative().default(0),
  minBufferThreshold: z.number().nonnegative().default(0),
});

trims.get('/', ah(async (req, res) => res.json(await buildTrims(req.query.orderId ? Number(req.query.orderId) : undefined))));
trims.get('/alerts', ah(async (_req, res) => res.json((await buildTrims()).filter((t) => t.lowStock))));
trims.post('/', ah(async (req, res) => res.status(201).json(await prisma.trimsInventory.create({ data: body.parse(req.body) }))));
trims.patch('/:id', ah(async (req, res) => res.json(await prisma.trimsInventory.update({ where: { id: idParam(req) }, data: body.partial().parse(req.body) }))));
trims.delete('/:id', ah(async (req, res) => {
  await prisma.trimsInventory.delete({ where: { id: idParam(req) } });
  res.status(204).end();
}));
