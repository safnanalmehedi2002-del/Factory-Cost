import { Router } from 'express';
import { z } from 'zod';
import { ah } from '../lib/http.js';
import { exportToSheets } from '../services/sheets.js';

export const exportRoutes = Router();

exportRoutes.post('/sheets', ah(async (req, res) => {
  const body = z
    .object({
      title: z.string().optional(),
      shareWith: z.array(z.string().email()).optional(),
      spreadsheetId: z.string().optional(), // pass to refresh an existing sheet in place (synced reporting)
    })
    .parse(req.body ?? {});
  res.json(await exportToSheets(body));
}));
