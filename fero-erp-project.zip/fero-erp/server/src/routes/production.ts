import { Router } from 'express';
import { z } from 'zod';
import { prisma, num } from '../db.js';
import { ah, idParam } from '../lib/http.js';
import { computeWip } from '../lib/calc.js';

export const production = Router();

const body = z.object({
  orderId: z.number().int().positive(),
  entryDate: z.coerce.date(),
  fabricReceivedKg: z.number().nonnegative().default(0),
  cuttingDailyPcs: z.number().int().nonnegative().default(0),
  sewingInputDailyPcs: z.number().int().nonnegative().default(0),
  sewingOutputDailyPcs: z.number().int().nonnegative().default(0),
  finishingPackingDailyPcs: z.number().int().nonnegative().default(0),
  lineShift: z.string().min(1).default('A'),
  remarks: z.string().nullish(),
});

/** Daily rows for an order, each with running cumulative totals and WIP. */
production.get('/', ah(async (req, res) => {
  const orderId = req.query.orderId ? Number(req.query.orderId) : undefined;
  const rows = await prisma.dailyProduction.findMany({
    where: orderId ? { orderId } : {},
    include: { order: { select: { styleNo: true, buyerName: true, totalOrderQty: true } } },
    orderBy: [{ entryDate: 'asc' }, { id: 'asc' }],
  });
  const run = new Map<number, { cut: number; sewIn: number; sewOut: number; packed: number; fabric: number }>();
  const out = rows.map((r) => {
    const c = run.get(r.orderId) ?? { cut: 0, sewIn: 0, sewOut: 0, packed: 0, fabric: 0 };
    c.cut += r.cuttingDailyPcs;
    c.sewIn += r.sewingInputDailyPcs;
    c.sewOut += r.sewingOutputDailyPcs;
    c.packed += r.finishingPackingDailyPcs;
    c.fabric += num(r.fabricReceivedKg);
    run.set(r.orderId, c);
    return {
      ...r,
      buyerName: r.order.buyerName,
      styleNo: r.order.styleNo,
      cumulative: { ...c },
      wip: computeWip({ orderQty: r.order.totalOrderQty, ...c }),
      order: undefined,
    };
  });
  res.json(out.reverse()); // newest first
}));

production.post('/', ah(async (req, res) => {
  res.status(201).json(await prisma.dailyProduction.create({ data: body.parse(req.body) }));
}));

production.patch('/:id', ah(async (req, res) => {
  res.json(await prisma.dailyProduction.update({ where: { id: idParam(req) }, data: body.partial().parse(req.body) }));
}));

production.delete('/:id', ah(async (req, res) => {
  await prisma.dailyProduction.delete({ where: { id: idParam(req) } });
  res.status(204).end();
}));
