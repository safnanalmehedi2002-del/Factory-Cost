import { Router } from 'express';
import { z } from 'zod';
import multer from 'multer';
import path from 'node:path';
import fs from 'node:fs';
import { prisma, num } from '../db.js';
import { ah, idParam, HttpError } from '../lib/http.js';
import { consumptionPerPcKg, convertLength, fabricBalanceKg, round, type Unit } from '../lib/calc.js';
import { buildReconciliation } from '../lib/summary.js';

export const fabric = Router();

export const UPLOAD_DIR = path.resolve(process.cwd(), 'uploads');
fs.mkdirSync(UPLOAD_DIR, { recursive: true });
const upload = multer({
  storage: multer.diskStorage({
    destination: UPLOAD_DIR,
    filename: (_req, file, cb) => cb(null, `${Date.now()}-${file.originalname.replace(/[^\w.-]/g, '_')}`),
  }),
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => cb(null, /^image\/(png|jpe?g|webp|gif)$/.test(file.mimetype)),
});

const body = z.object({
  orderId: z.number().int().positive(),
  slNo: z.number().int().positive().optional(),
  fabricType: z.string().min(1),
  colorRef: z.string().min(1),
  gsm: z.number().positive(),
  dia: z.number().positive(),
  unit: z.enum(['CM', 'INC']).default('CM'),
  bodyLength: z.number().positive(),
  chestHalf: z.number().positive(),
  sleeveLength: z.number().nonnegative(),
  wastagePct: z.number().min(0).max(100).default(5),
  fabricReceivedKg: z.number().nonnegative().default(0),
  cuttingQtyPcs: z.number().int().nonnegative().default(0),
  challanNo: z.string().nullish(),
  snapshotImageUrl: z.string().nullish(),
  remarks: z.string().nullish(),
});

const calcRow = (r: {
  unit: Unit; bodyLength: number; chestHalf: number; sleeveLength: number; gsm: number; wastagePct: number;
}) => round(consumptionPerPcKg(r), 5);

function decorate(r: Awaited<ReturnType<typeof prisma.cuttingFabricGrid.findFirstOrThrow>>) {
  const cons = num(r.consumptionPerPcKg);
  const fb = fabricBalanceKg(num(r.fabricReceivedKg), r.cuttingQtyPcs, cons);
  return {
    ...r,
    consumptionPerDozenKg: round(cons * 12, 4),
    requiredForCutKg: round(fb.requiredForCut, 3),
    balanceKg: round(fb.balance, 3),
  };
}

fabric.get('/', ah(async (req, res) => {
  const orderId = req.query.orderId ? Number(req.query.orderId) : undefined;
  const rows = await prisma.cuttingFabricGrid.findMany({ where: orderId ? { orderId } : {}, orderBy: [{ orderId: 'asc' }, { slNo: 'asc' }] });
  res.json(rows.map(decorate));
}));

fabric.get('/reconciliation', ah(async (_req, res) => res.json(await buildReconciliation())));

fabric.post('/', ah(async (req, res) => {
  const d = body.parse(req.body);
  const slNo = d.slNo ?? ((await prisma.cuttingFabricGrid.aggregate({ where: { orderId: d.orderId }, _max: { slNo: true } }))._max.slNo ?? 0) + 1;
  const row = await prisma.cuttingFabricGrid.create({ data: { ...d, slNo, consumptionPerPcKg: calcRow(d) } });
  res.status(201).json(decorate(row));
}));

fabric.patch('/:id', ah(async (req, res) => {
  const id = idParam(req);
  const cur = await prisma.cuttingFabricGrid.findUnique({ where: { id } });
  if (!cur) throw new HttpError(404, 'Row not found');
  const patch = body.partial().parse(req.body);
  const merged = {
    unit: (patch.unit ?? cur.unit) as Unit,
    bodyLength: patch.bodyLength ?? num(cur.bodyLength),
    chestHalf: patch.chestHalf ?? num(cur.chestHalf),
    sleeveLength: patch.sleeveLength ?? num(cur.sleeveLength),
    gsm: patch.gsm ?? num(cur.gsm),
    wastagePct: patch.wastagePct ?? num(cur.wastagePct),
  };
  const row = await prisma.cuttingFabricGrid.update({ where: { id }, data: { ...patch, consumptionPerPcKg: calcRow(merged) } });
  res.json(decorate(row));
}));

/** Bidirectional unit switch for every row of an order. Consumption is unchanged (it is unit independent). */
fabric.post('/convert', ah(async (req, res) => {
  const { orderId, unit } = z.object({ orderId: z.number().int().positive(), unit: z.enum(['CM', 'INC']) }).parse(req.body);
  const rows = await prisma.cuttingFabricGrid.findMany({ where: { orderId } });
  await prisma.$transaction(
    rows.filter((r) => r.unit !== unit).map((r) =>
      prisma.cuttingFabricGrid.update({
        where: { id: r.id },
        data: {
          unit,
          bodyLength: round(convertLength(num(r.bodyLength), r.unit, unit), 4),
          chestHalf: round(convertLength(num(r.chestHalf), r.unit, unit), 4),
          sleeveLength: round(convertLength(num(r.sleeveLength), r.unit, unit), 4),
        },
      }),
    ),
  );
  const out = await prisma.cuttingFabricGrid.findMany({ where: { orderId }, orderBy: { slNo: 'asc' } });
  res.json(out.map(decorate));
}));

fabric.post('/:id/snapshot', upload.single('image'), ah(async (req, res) => {
  if (!req.file) throw new HttpError(400, 'Attach an image (png/jpg/webp/gif, max 5MB) as field "image"');
  const row = await prisma.cuttingFabricGrid.update({ where: { id: idParam(req) }, data: { snapshotImageUrl: `/uploads/${req.file.filename}` } });
  res.json(decorate(row));
}));

fabric.delete('/:id', ah(async (req, res) => {
  await prisma.cuttingFabricGrid.delete({ where: { id: idParam(req) } });
  res.status(204).end();
}));
