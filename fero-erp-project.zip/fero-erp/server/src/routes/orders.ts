import { Router } from 'express';
import { z } from 'zod';
import { prisma } from '../db.js';
import { ah, idParam, HttpError } from '../lib/http.js';
import { buildOrderSummaries } from '../lib/summary.js';

export const orders = Router();

const orderBody = z.object({
  buyerName: z.string().min(1),
  styleNo: z.string().min(1),
  itemDescription: z.string().min(1),
  colorWash: z.string().min(1),
  totalOrderQty: z.number().int().positive(),
  unitConsumptionKg: z.number().nonnegative(),
  shipmentDeadline: z.coerce.date(),
});

orders.get('/', ah(async (_req, res) => res.json(await buildOrderSummaries())));

orders.get('/:id', ah(async (req, res) => {
  const [o] = await buildOrderSummaries(idParam(req));
  if (!o) throw new HttpError(404, 'Order not found');
  res.json(o);
}));

orders.post('/', ah(async (req, res) => {
  const data = orderBody.parse(req.body);
  res.status(201).json(await prisma.masterOrder.create({ data }));
}));

orders.patch('/:id', ah(async (req, res) => {
  const data = orderBody.partial().parse(req.body);
  res.json(await prisma.masterOrder.update({ where: { id: idParam(req) }, data }));
}));

orders.delete('/:id', ah(async (req, res) => {
  await prisma.masterOrder.delete({ where: { id: idParam(req) } });
  res.status(204).end();
}));
