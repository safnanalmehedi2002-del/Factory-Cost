import { PrismaClient, Prisma } from '@prisma/client';

// Serialise Prisma Decimals as JSON numbers (default is string).
(Prisma.Decimal.prototype as unknown as { toJSON: () => number }).toJSON = function (this: Prisma.Decimal) {
  return this.toNumber();
};

export const prisma = new PrismaClient();
export const num = (d: Prisma.Decimal | number | null | undefined): number => (d == null ? 0 : Number(d));
