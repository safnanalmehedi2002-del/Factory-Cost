import express from 'express';
import cors from 'cors';
import { errorHandler, ah } from './lib/http.js';
import { buildDashboard } from './lib/summary.js';
import { orders } from './routes/orders.js';
import { production } from './routes/production.js';
import { fabric, UPLOAD_DIR } from './routes/fabric.js';
import { trims } from './routes/trims.js';
import { exportRoutes } from './routes/export.js';
import { consumptionPerPcKg, wovenConsumptionPerPcKg } from './lib/calc.js';
import { z } from 'zod';

export function createApp() {
  const app = express();
  app.use(cors({ origin: process.env.CORS_ORIGIN?.split(',') ?? true }));
  app.use(express.json({ limit: '1mb' }));
  app.use('/uploads', express.static(UPLOAD_DIR));

  app.get('/api/health', (_req, res) => res.json({ ok: true }));
  app.get('/api/dashboard', ah(async (_req, res) => res.json(await buildDashboard())));
  app.use('/api/orders', orders);
  app.use('/api/production', production);
  app.use('/api/fabric', fabric);
  app.use('/api/trims', trims);
  app.use('/api/export', exportRoutes);

  // Stateless yield simulator (same engine the UI uses locally).
  app.post('/api/calc/yield', (req, res) => {
    const knit = z.object({ mode: z.literal('knit'), unit: z.enum(['CM', 'INC']), bodyLength: z.number(), chestHalf: z.number(), sleeveLength: z.number(), gsm: z.number(), wastagePct: z.number() });
    const woven = z.object({ mode: z.literal('woven'), unit: z.enum(['CM', 'INC']), markerLength: z.number(), fabricWidth: z.number(), pcsPerMarker: z.number(), gsm: z.number(), wastagePct: z.number() });
    const i = z.discriminatedUnion('mode', [knit, woven]).parse(req.body);
    const kgPerPc = i.mode === 'knit' ? consumptionPerPcKg(i) : wovenConsumptionPerPcKg(i);
    res.json({ kgPerPc, kgPerDozen: kgPerPc * 12 });
  });

  app.use(errorHandler);
  return app;
}
